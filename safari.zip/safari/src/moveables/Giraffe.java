package src.moveables;

import javax.swing.*;
import java.awt.*;


/**
 * A Giraffe osztály a zsiráfot reprezentálja a térképen.
 * A zsiráf egy növényevő állat, amely egy adott helyet foglal el a térképen.
 * A zsiráf képe a "giraffe.png" fájlból töltődik be.
 */
public class Giraffe extends Herbivore {
    private static int idGen = 0;
    public static final int price = 280;
    public static final int sellPrice = 250;

    /**
     * Konstruktor, amely inicializálja a zsiráf pozícióját, méretét és képét.
     *
     * @param x      A zsiráf vízszintes koordinátája.
     * @param y      A zsiráf függőleges koordinátája.
     * @param width  A zsiráf szélessége.
     * @param height A zsiráf magassága.
     */
    public Giraffe(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/giraffe.png").getImage(), "Giraffe #" + (++idGen));
    }
}
