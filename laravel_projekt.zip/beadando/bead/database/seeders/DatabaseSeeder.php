<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Enclosure;
use App\Models\Animal;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;

namespace Database\Seeders;

use App\Models\User;
use App\Models\Enclosure;
use App\Models\Animal;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $faker = Faker::create();


        // Admin user létrehozása
        User::create([
        'name' => 'Admin Felhasználó',
        'email' => 'admin@admin.com',
        'password' => bcrypt('admin'),
        'admin' => true,


]);

Enclosure::create([
    'name' => 'Örök vadászmező',
    'limit' => 10,
    'feeding_at' => '08:00:00',

]);


        // Create 8 users (gondozók)
        $users = User::factory(8)->create();

        // Create 10 enclosures (kifutók)
        $enclosures = Enclosure::factory(10)->create(); // Factory alkalmazása

        // Loop through each enclosure and add animals
        foreach ($enclosures as $enclosure) {
            // Determining if the enclosure will contain predators or not
            $containsPredators = $faker->boolean(50); // 50% esély arra, hogy ragadozók legyenek benne

            // Create animals for each enclosure
            $animalsCount = $faker->numberBetween(1, $enclosure->limit);

            for ($i = 0; $i < $animalsCount; $i++) {
                $animalName = $faker->word;
                $animalSpecies = $faker->word;
                $isPredator = $containsPredators ? true : false;
                $bornAt = $faker->dateTimeBetween('-5 years', 'now');
                $image = $faker->imageUrl(640, 480, 'animals', true);

                // Create animal
                Animal::create([
                    'name' => $animalName,
                    'species' => $animalSpecies,
                    'is_predator' => $isPredator,
                    'born_at' => $bornAt,
                    'image' => $image,
                    'enclosure_id' => $enclosure->id,
                ]);

            }
        }

        // Assign enclosures to users (gondozók)
        foreach ($users as $user) {
            $user->enclosures()->attach($enclosures->random(3)->pluck('id')->toArray()); // Helyes csatolás
        }
    }
}
