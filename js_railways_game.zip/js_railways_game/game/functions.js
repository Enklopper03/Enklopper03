const levels = {
    easy: [
    [
        // 5x5 pálya adatok
        ['empty', 'mountain_bal', 'empty', 'empty', 'oasis'],
        ['empty', 'empty', 'empty', 'bridge_ver', 'oasis'],
        ['bridge_ver', 'empty', 'mountain_down', 'empty', 'empty'],
        ['empty', 'empty', 'empty', 'oasis', 'empty'],
        ['empty', 'empty', 'mountain_up', 'empty', 'empty']
    ],
    [
        // 5x5 pálya adatok
        ['oasis', 'empty', 'bridge', 'empty', 'empty'],
        ['empty', 'mountain_down', 'empty', 'empty', 'mountain_down'],
        ['bridge_ver', 'oasis', 'mountain_up', 'empty', 'empty'],
        ['empty', 'empty', 'empty', 'oasis', 'empty'],
        ['empty', 'empty', 'empty', 'empty', 'empty']
    ],
    [
        // 5x5 pálya adatok
        ['empty', 'empty', 'bridge', 'empty', 'empty'],
        ['empty', 'empty', 'empty', 'empty', 'bridge_ver'],
        ['empty', 'mountain_down', 'bridge_ver', 'empty', 'empty'],
        ['empty', 'oasis', 'empty', 'empty', 'empty'],
        ['empty', 'bridge', 'empty', 'empty', 'mountain_down']
    ],
    [
        // 5x5 pálya adatok
        ['empty', 'empty', 'empty', 'bridge', 'empty'],
        ['empty', 'empty', 'empty', 'empty', 'empty'],
        ['bridge_ver', 'empty', 'mountain_bal', 'empty', 'mountain_bal'],
        ['empty', 'empty', 'empty', 'empty', 'empty'],
        ['empty', 'empty', 'oasis', 'mountain_up', 'empty']
    ],
    [
        // 5x5 pálya adatok
        ['empty', 'empty', 'bridge', 'empty', 'empty'],
        ['empty', 'mountain', 'empty', 'empty', 'empty'],
        ['bridge_ver', 'empty', 'empty', 'mountain_up', 'empty'],
        ['empty', 'empty', 'bridge_ver', 'oasis', 'empty'],
        ['empty', 'mountain_down', 'empty', 'empty', 'empty']
    ]
    ],

    hard: [
        // 7x7 pálya adatok
        [
            ['empty', 'mountain_bal', 'oasis', 'oasis', 'empty', 'bridge', 'empty'],
            ['bridge_ver', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'bridge_ver', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'mountain_up', 'empty', 'empty', 'empty'],
            ['mountain_up', 'empty', 'mountain_bal', 'empty', 'bridge', 'empty', 'oasis'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'bridge', 'empty', 'empty', 'empty']
        ],
        [
            ['empty', 'empty', 'oasis', 'empty', 'empty', 'empty', 'empty'],
            ['bridge_ver', 'empty', 'bridge', 'empty', 'empty', 'mountain_down', 'empty'],
            ['empty', 'empty', 'bridge', 'empty', 'empty', 'empty', 'bridge_ver'],
            ['mountain', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'oasis', 'empty', 'mountain_bal', 'empty', 'empty', 'empty'],
            ['empty', 'mountain', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'oasis', 'empty', 'empty', 'empty', 'empty']
        ],
        [
            ['empty', 'bridge', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'bridge_ver'],
            ['oasis', 'empty', 'mountain_up', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'oasis', 'mountain_up', 'empty', 'bridge', 'empty', 'empty'],
            ['bridge_ver', 'empty', 'empty', 'empty', 'empty', 'mountain_bal', 'empty'],
            ['empty', 'empty', 'oasis', 'mountain_up', 'empty', 'empty', 'empty']
        ],
        [
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'bridge_ver', 'empty', 'mountain_down', 'empty'],
            ['empty', 'empty', 'mountain_up', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'bridge', 'empty', 'oasis', 'empty', 'bridge', 'empty'],
            ['empty', 'empty', 'mountain_down', 'empty', 'mountain_bal', 'empty', 'empty'],
            ['bridge_ver', 'empty', 'empty', 'empty', 'empty', 'mountain_up', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty']
        ],
        [
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'mountain', 'empty'],
            ['empty', 'bridge', 'bridge', 'empty', 'mountain_bal', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'mountain', 'empty', 'oasis', 'empty', 'empty'],
            ['empty', 'mountain_down', 'empty', 'bridge_ver', 'empty', 'empty', 'empty'],
            ['empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty']
        ],
        
    ]
};
let timerInterval;

function startGame(playerName, difficulty) {
    console.log(`A játék elindult! Játékos neve: ${playerName}, Nehézség: ${difficulty}`);

    const levelIndex = Math.floor(Math.random() * levels[difficulty].length);
    const level = levels[difficulty][levelIndex];
    console.log('Pálya:', level);

    document.querySelector('#player-name-display').textContent = `${playerName}`;


    if (timerInterval) {
        clearInterval(timerInterval);
    }
    let startTime = Date.now();
    timerInterval = setInterval(() => {
        let elapsedTime = Date.now() - startTime;
        let seconds = Math.floor(elapsedTime / 1000);
        let minutes = Math.floor(seconds / 60);
        seconds = seconds % 60;
        const formattedMinutes = String(minutes).padStart(2, '0');
        const formattedSeconds = String(seconds).padStart(2, '0');
        document.querySelector('#elapsed-time').textContent = `${formattedMinutes}:${formattedSeconds}`;


     
    }, 1000);

    const gameBoard = document.querySelector('#game-board');
    gameBoard.innerHTML = '';

    const table = document.createElement('table');
    table.style.borderCollapse = 'collapse'; // Cellák közötti rés eltávolítása

    level.forEach((row, rowIndex) => {
        const tr = document.createElement('tr');
        row.forEach((cell, colIndex) => {
            const td = document.createElement('td');
            td.classList.add('cell');
            td.dataset.type = cell;
            td.dataset.row = rowIndex;
            td.dataset.col = colIndex;

            if(difficulty === 'easy') {
            const img = document.createElement('img');
            img.src = `../pics/tiles/${cell}.png`;
            td.appendChild(img);
            }
            else {
                const cont = document.querySelector('#game-board-container');
                const img = document.createElement('img');
                img.src = `../pics/tiles/${cell}.png`;
                td.appendChild(img);
                td.style.width = '72px';
                td.style.height = '72px';
            }
            td.addEventListener('click', (event) => {
                event.preventDefault();
                if (event.button === 0) { // Bal klikk
                    if (cell === 'oasis' || td.dataset.fixed === 'true') {
                        return; // Oázis mezőre és fixált cellára nem lehet sínt rakni
                    }

                    const existingTrack = td.querySelector('.rail-track');
                    if (existingTrack) {
                        if (existingTrack.src.includes('straight_rail.png')) {
                            existingTrack.src = '../pics/tiles/curve_rail.png';
                        } else {
                            existingTrack.src = '../pics/tiles/straight_rail.png';
                        }
                    } else {
                        const railTrack = document.createElement('img');
                        if (cell === 'bridge') {
                            railTrack.src = '../pics/tiles/bridge_rail.png'; 
                        } else if (cell === 'bridge_ver') {
                            railTrack.src = '../pics/tiles/bridge_rail_ver.png'; 
                        } else if (cell === 'mountain') {
                            railTrack.src = '../pics/tiles/mountain_rail.png';
                        } else if (cell === 'mountain_bal') {
                            railTrack.src = '../pics/tiles/mountain_rail_bal.png';
                        } else if (cell === 'mountain_up') {
                            railTrack.src = '../pics/tiles/mountain_rail_up.png';
                        } else if (cell === 'mountain_down') {
                            railTrack.src = '../pics/tiles/mountain_rail_dodown.png';
                        } else {
                            railTrack.src = '../pics/tiles/straight_rail.png';
                        }
                        railTrack.classList.add('rail-track');
                        railTrack.dataset.rotation = 0;
                        td.appendChild(railTrack);

                        // Fixáljuk a cellát, ha mountain vagy bridge típusú
                        if (cell.startsWith('bridge') || cell.startsWith('mountain')) {
                            td.dataset.fixed = 'true';
                        }
                    }
                }
            });

            td.addEventListener('contextmenu', (event) => {
                event.preventDefault();
                const existingTrack = td.querySelector('.rail-track');
                if (existingTrack && !td.dataset.fixed) {
                    const currentRotation = parseInt(existingTrack.dataset.rotation) || 0;
                    const newRotation = (currentRotation + 90) % 360;
                    existingTrack.style.transform = `rotate(${newRotation}deg)`;
                    existingTrack.dataset.rotation = newRotation;
                }
            });

            td.addEventListener('mousedown', (event) => {
                if (event.button === 1) { // Középső klikk
                    event.preventDefault();
                    const existingTrack = td.querySelector('.rail-track');
                    if (existingTrack && !td.dataset.fixed) {
                        td.removeChild(existingTrack);
                    }
                }
            });

            tr.appendChild(td);
        });
        table.appendChild(tr);
    });

    gameBoard.appendChild(table);

    
    document.querySelector('#check-solution').addEventListener('click', () => {
        const errorMessage2 = document.querySelector('#error-message2');
        const messageDiv = document.querySelector('#message');
        if (checkSolution(level)) {
            clearInterval(timerInterval);
            const elapsedTime = Date.now() - startTime;
            const seconds = Math.floor(elapsedTime / 1000);
            const minutes = Math.floor(seconds / 60);
            const formattedMinutes = String(minutes).padStart(2, '0');
            const formattedSeconds = String(seconds % 60).padStart(2, '0');
            messageDiv.textContent = `Játék vége! Teljesítési idő: ${formattedMinutes}:${formattedSeconds}`;
            messageDiv.style.display = 'block';
            errorMessage2.style.display = 'none';
    
            // Toplista frissítése
            const playerName = document.querySelector('#player-name-display').textContent;
            updateToplist(playerName, selectedDifficulty, elapsedTime);
        } else {
            errorMessage2.textContent = 'A feladvány nincs megoldva helyesen.';
            errorMessage2.style.display = 'block';
        }
    });
}

function updateToplist(playerName, difficulty, time) {
    const toplistKey = `toplist-${difficulty}`;
    let toplist = JSON.parse(localStorage.getItem(toplistKey)) || [];
    toplist.push({ playerName, time });
    toplist.sort((a, b) => a.time - b.time); // Idő szerint rendezés
    toplist = toplist.slice(0, 10); // Csak az első 10 eredmény
    localStorage.setItem(toplistKey, JSON.stringify(toplist));
    displayToplist(difficulty);
}

function displayToplist(difficulty) {
    const toplistKey = `toplist-${difficulty}`;
    const toplist = JSON.parse(localStorage.getItem(toplistKey)) || [];
    const toplistContainer = document.querySelector('#toplist');
    toplistContainer.innerHTML = ''; // Töröljük a meglévő elemeket
    toplist.forEach((entry, index) => {
        const listItem = document.createElement('li');
        listItem.textContent = `${index + 1}. ${entry.playerName} - ${formatTime(entry.time)}`;
        toplistContainer.appendChild(listItem);
    });
    document.querySelector('#toplist-container').style.display = 'block';
    document.querySelector('#game-info2').style.display = 'none';
}

function formatTime(time) {
    const seconds = Math.floor(time / 1000);
    const minutes = Math.floor(seconds / 60);
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds % 60).padStart(2, '0');
    return `${formattedMinutes}:${formattedSeconds}`;
}

function checkSolution(level) {
    const rows = level.length;
    const cols = level[0].length;
    const visited = new Set();
    let startCell = null;

    // Keressük meg a kezdő cellát (az első cellát, amelyen sín van)
    outerLoop:
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const cell = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
            if (cell && cell.querySelector('.rail-track')) {
                startCell = { row, col };
                break outerLoop;
            }
        }
    }

    if (!startCell) return false;

    function dfs(cell, parent) {
        const { row, col } = cell;
        const key = `${row},${col}`;
        if (visited.has(key)) return false;
        visited.add(key);

        // Ellenőrizzük a szomszédos cellákat
        const directions = [
            { row: -1, col: 0 }, // fel
            { row: 1, col: 0 },  // le
            { row: 0, col: -1 }, // balra
            { row: 0, col: 1 }   // jobbra
        ];

        let hasCycle = false;
        for (const dir of directions) {
            const newRow = row + dir.row;
            const newCol = col + dir.col;
            const newKey = `${newRow},${newCol}`;
            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) {
                const neighbor = document.querySelector(`.cell[data-row="${newRow}"][data-col="${newCol}"]`);
                if (neighbor && neighbor.querySelector('.rail-track')) {
                    if (newKey !== parent) {
                        hasCycle = hasCycle || dfs({ row: newRow, col: newCol }, key);
                    }
                }
            }
        }
        return hasCycle || (parent && visited.size === rows * cols - document.querySelectorAll('.cell[data-type="oasis"]').length);
    }

    const isCycle = dfs(startCell, null);

    // Ellenőrizzük, hogy minden cellát meglátogattunk-e, amelyen sín van
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const cell = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
            if (cell && cell.querySelector('.rail-track') && !visited.has(`${row},${col}`)) {
                return false;
            }
        }
    }

    // Ellenőrizzük, hogy a sínek egy összefüggő kört alkotnak-e
    if (visited.size !== document.querySelectorAll('.cell .rail-track').length) {
        return false;
    }

    return isCycle;
}