from django.urls import path
from .views import DomainDecisionView, form_view, DomainDecisionListView, DomainDecisionDetailView, DomainDecisionDeleteView, DomainDecisionUpdateView

urlpatterns = [
    path("check/", DomainDecisionView.as_view(), name="domain-check"),
    path("list/", DomainDecisionListView.as_view(), name="domain-decision-list"),
    path("check/<str:domain>/", DomainDecisionDetailView.as_view(), name="domain-decision-detail"),
    path("delete/<str:domain>/", DomainDecisionDeleteView.as_view(), name="domain-decision-delete"),
    path("update/<str:domain>/", DomainDecisionUpdateView.as_view(), name="domain-decision-update"),
    path("", form_view, name="form-view"),
]
