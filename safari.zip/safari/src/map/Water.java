package src.map;

import javax.swing.*;
import java.awt.*;

public class Water {
    private  int x;
    private  int y;
    private  int width;
    private  int height;

    private Image image;

    public Water(int x, int y, int width, int height, Image image) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
    }
}
