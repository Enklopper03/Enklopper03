<?php

namespace Database\Factories;

use App\Models\Enclosure;
use Illuminate\Database\Eloquent\Factories\Factory;

class EnclosureFactory extends Factory
{
    protected $model = Enclosure::class;

    public function definition()
    {
        return [
            'name' => $this->faker->word, // Kifutó neve
            'limit' => $this->faker->numberBetween(1, 10), // Maximális állatszám
            'feeding_at' => $this->faker->time, // Etetési időpont
        ];
    }
}
