@extends('layouts.app')

@section('content')
<div class="container">
    <h2>{{ $enclosure->name }}</h2>

    <p><strong>Állat limit:</strong> {{ $enclosure->limit }}</p>
    <p><strong>Jelenlegi állatok száma:</strong> {{ $enclosure->animals->count() }}</p>

    @if($hasPredators)
        <div class="alert alert-danger">
            ⚠️ FIGYELEM: Ragadozó(k) található(k) a kifutóban!
        </div>
    @endif

    <h3>Állatok a kifutóban:</h3>
    @if($enclosure->animals->isEmpty())
        <p>Nincsenek állatok a kifutóban.</p>
    @else
    <table class="table">
        <thead>
            <tr>
                <th>Kép</th>
                <th>Név</th>
                <th>Faj</th>
                <th>Születési idő</th>
                @auth
                    @if(auth()->user()->admin || $enclosure->user_id == auth()->id())
                        <th>Akciók</th>
                    @endif
                @endauth
                @auth
                @if(auth()->user()->admin || $enclosure->user_id == auth()->id())
                <div class="mb-3">
                    <a href="{{ route('animals.create') }}" class="btn btn-success">Új állat létrehozása</a>
                </div>
                @endif
                @endauth
                @auth
    @if(auth()->user()->admin)
        <a href="{{ route('animals.archived') }}" class="btn btn-secondary">Archivált állatok</a>
    @endif
@endauth

            </tr>
        </thead>
        <tbody>
            @foreach($enclosure->animals as $animal)
                <tr>
                    <td>
                        @if($animal->image)
                            <img src="{{ asset('storage/' . $animal->image) }}" alt="Állat képe" width="80">
                        @else
                            <img src="{{ asset('images/placeholder.png') }}" alt="Placeholder" width="80">
                        @endif
                    </td>
                    <td>{{ $animal->name }}</td>
                    <td>{{ $animal->species }}</td>
                    <td>
                        @if($animal->born_at)
                            {{ $animal->born_at }}
                        @else
                            N/A
                        @endif
                    </td>
                    <td>
                        @auth
                            @if(auth()->user()->admin || $animal->user_id == auth()->id())
                                <a href="{{ route('animals.edit', $animal->id) }}" class="btn btn-warning btn-sm">Szerkesztés</a>
                                @if (!$animal->deleted_at)
                                    <form action="{{ route('animals.archive', $animal) }}" method="POST" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Archiválás</button>
                                    </form>
                                @else
                                    <span class="text-muted">Archiválva</span>
                                @endif
                            @endif
                        @endauth
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    @endif
    <a href="{{ route('enclosure') }}" class="btn btn-secondary">Vissza a kifutókhoz</a>
</div>
@endsection
