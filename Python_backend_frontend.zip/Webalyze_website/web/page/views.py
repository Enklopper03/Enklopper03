from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from .models import DomainDecision
from .serializers import DomainDecisionSerializer
from .serializers import DomainDecisionUpdateSerializer
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from .utils import generate_domain_decision
import random


def form_view(request):
    return render(request, "form.html")

@method_decorator(csrf_exempt, name='dispatch')
class DomainDecisionView(APIView):
    def get(self, request):
        return Response({"message": "Use POST to check domain."}, status=status.HTTP_200_OK)

    def post(self, request):
        print("POST arrived:", request.data)
        serializer = DomainDecisionSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        domain = serializer.validated_data['domain']

        try:
            decision_obj = DomainDecision.objects.get(domain=domain)
            serializer = DomainDecisionSerializer(decision_obj)
            return Response(serializer.data)
        except DomainDecision.DoesNotExist:
            pass

        # decision generation logic
        result = generate_domain_decision(domain)

        # If decision is False, we don't save it
        if not result["decision"]:
            return Response(result, status=status.HTTP_200_OK)

        # If decision is True, save to database
        decision_obj = DomainDecision.objects.create(
            domain=result["domain"],
            decision=True,
            number=result["number"],
            generated_at=result["generated_at"]
        )

        serializer = DomainDecisionSerializer(decision_obj)
        return Response(serializer.data)


class DomainDecisionListView(APIView):
    def get(self, request):
        decisions = DomainDecision.objects.all()
        serializer = DomainDecisionSerializer(decisions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class DomainDecisionDetailView(APIView):
    def get(self, request, domain):
        try:
            decision = DomainDecision.objects.get(domain=domain)
            serializer = DomainDecisionSerializer(decision)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except DomainDecision.DoesNotExist:
            return Response({"error": "Domain decision not found."}, status=status.HTTP_404_NOT_FOUND)


class DomainDecisionDeleteView(APIView):
    def delete(self, request, domain):
        try:
            decision = DomainDecision.objects.get(domain=domain)
            decision.delete()
            return Response({"message": "Domain decision deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
        except DomainDecision.DoesNotExist:
            return Response({"error": "Domain decision not found."}, status=status.HTTP_404_NOT_FOUND)


class DomainDecisionUpdateView(APIView):
    def put(self, request, domain):
        try:
            decision = DomainDecision.objects.get(domain=domain)
        except DomainDecision.DoesNotExist:
            return Response({"error": "Domain decision not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = DomainDecisionUpdateSerializer(decision, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Itt menti az új adatokat
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
