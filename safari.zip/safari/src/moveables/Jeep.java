package src.moveables;

import src.main.GameEngine;
import src.utils.Direction;

import java.awt.*;
import java.util.Random;


/**
 * A Jeep osztály a játékban mozgó dzsipeket reprezentálja, amelyek látogatókat szállítanak
 * az állatkert bejáratától a kijáratig, majd visszatérnek.
 */
public class Jeep extends Moveable {
    private static int count = 0;
    private int id = ++count;
    private final Random rand = new Random();
    private static final int capacity = 4;
    public static final int price = 3500;
    private int passengers = 0;
    public int speed = 0;
    private int speedMultiplier = 1;
    private boolean movingToExit = true;



    /**
     * Beállítja a sebességszorzót.
     * @param speed A szorzó értéke.
     */
    public void setSpeed(int speed) { speedMultiplier = speed; }
    public boolean isMoving() { return speed > 0; }


    /**
     * Elindítja a dzsip mozgását.
     */
    private void startMoving() {
        speed = 2;
        System.out.println("Jeep #" + id + " started moving");
    }


    /**
     * Megállítja a dzsip mozgását.
     */
    private void stopMoving() {
        speed = 0;
        System.out.println("Jeep #" + id + " stopped moving");
    }

    /**
     * Hozzáad egy utast a dzsiphez, ha van hely.
     */
    public void addPassenger() {
        if (passengers < capacity) {
            passengers++;
            System.out.println("Jeep #" + id + " passengers: " + passengers);
        } else {
            System.out.println("Jeep #" + id + " is full!");
        }
    }

    /**
     * Kiválasztja az utasokat a dzsipből.
     */
    private void emptyPassengers() { passengers = 0; }



    /**
     * Konstruktor a Jeep objektum létrehozásához.
     *
     * @param x           A dzsip vízszintes koordinátája.
     * @param y           A dzsip függőleges koordinátája.
     * @param directionX  A dzsip vízszintes iránya.
     * @param directionY  A dzsip függőleges iránya.
     * @param speed       A dzsip sebessége.
     * @param width       A dzsip szélessége.
     * @param height      A dzsip magassága.
     * @param image       A dzsip képe.
     */
    public Jeep(int x, int y, Direction directionX, Direction directionY, int speed, int width, int height, Image image) {
        super(x, y, directionX, directionY, width, height, image);
    }


    /**
     * A dzsip mozgásáért felelős metódus.
     * A dzsip akkor indul el, ha legalább 2 utas van benne, és random feltétel teljesül.
     * Ha elérte a kijáratot, kiüríti az utasokat, és visszafordul a bejárathoz.
     * Ha visszatért a bejárathoz, megáll.
     */
    @Override
    public void move() {
        if (!isMoving() && passengers >= 2 && rand.nextInt(5) == 0) {
            startMoving();
        } else if (isMoving()) {
            if (movingToExit) {
                double dxExit = GameEngine.mapData.exit.x - getX();
                double dyExit = GameEngine.mapData.exit.y - getY();
                double distanceToExit = Math.sqrt(dxExit * dxExit + dyExit * dyExit);
                if (distanceToExit > 2 * speedMultiplier) {
                    moveTowardsExit();
                } else {
                    emptyPassengers();
                    movingToExit = false;
                    System.out.println("Jeep #" + id + " reached exit, moving back to entrance");
                }
            } else {
                double dxEntrance = GameEngine.mapData.entrance.x - getX();
                double dyEntrance = GameEngine.mapData.entrance.y - getY();
                double distanceToEntrance = Math.sqrt(dxEntrance * dxEntrance + dyEntrance * dyEntrance);
                if (distanceToEntrance > 2 * speedMultiplier) {
                    moveTowardsEntrance();
                } else {
                    stopMoving();
                    movingToExit = true;
                }
            }
        }
    }



    /**
     * A dzsip mozgatása a bejárat felé.
     */
    private void moveTowardsEntrance() {
        double dxEntrance = GameEngine.mapData.entrance.x - getX();
        double dyEntrance = GameEngine.mapData.entrance.y - getY();
        double distanceToEntrance = Math.sqrt(dxEntrance * dxEntrance + dyEntrance * dyEntrance);
        double moveX = (dxEntrance / distanceToEntrance) * speed * speedMultiplier;
        double moveY = (dyEntrance / distanceToEntrance) * speed * speedMultiplier;
        setX((int) (getX() + moveX));
        setY((int) (getY() + moveY));
    }


    /**
     * A dzsip mozgatása a kijárat felé.
     */
    private void moveTowardsExit() {
        double dxExit = GameEngine.mapData.exit.x - getX();
        double dyExit = GameEngine.mapData.exit.y - getY();
        double distanceToExit = Math.sqrt(dxExit * dxExit + dyExit * dyExit);
        double moveX = (dxExit / distanceToExit) * speed * speedMultiplier;
        double moveY = (dyExit / distanceToExit) * speed * speedMultiplier;
        setX((int) (getX() + moveX));
        setY((int) (getY() + moveY));
    }
}
