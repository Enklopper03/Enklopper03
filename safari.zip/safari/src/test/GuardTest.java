package src.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.map.MapData;
import src.moveables.*;
import src.utils.Direction;
import src.main.GameEngine;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static src.main.GameEngine.carnivores;

public class GuardTest {

    private Guard guard;
    private Carnivore carnivore;
    private Hunter hunter;

    @BeforeEach
    public void setUp() throws IOException {
        guard = new Guard(100, 100, Direction.RIGHT, Direction.DOWN, 2, 50, 50, null, carnivore);
        hunter = new Hunter(200, 200, Direction.RIGHT, Direction.DOWN, 2, 50, 50);
        carnivore = new Lion(200, 200, 50, 50);
        carnivores = new ArrayList<>();

        MapData map = new MapData("src/main/levels/level0.txt");
        map.hunters.add(hunter);
        carnivores.add(carnivore);

        GameEngine.mapData = map;
    }

    @Test
    public void testGuardConstructor() {
        int x = 100;
        int y = 200;
        Direction dirX = Direction.RIGHT;
        Direction dirY = Direction.DOWN;
        int speed = 3;
        int width = 50;
        int height = 60;
        Image image = null;
        Carnivore carnivore = null;

        Guard guard = new Guard(x, y, dirX, dirY, speed, width, height, image, carnivore);

        assertEquals(x, guard.getX());
        assertEquals(y, guard.getY());
        assertEquals(width, guard.getWidth());
        assertEquals(height, guard.getHeight());
    }

    @Test
    public void testGuardShootsCarnivoreWhenClose() {
        guard.setX(198);
        guard.setY(198);
        guard.setHuntedAnimal(carnivore);
        guard.move();

        assertFalse(GameEngine.carnivores.contains(carnivore), "Carnivore should be removed (shot)");
        assertNull(guard.getHuntedAnimal(), "Guard should clear target after shooting");
    }

    @Test
    public void testGuardTargetSwitching() {
        Carnivore anotherCarnivore = new Leopard(300, 300, 50, 50);
        guard.setHuntedAnimal(anotherCarnivore);

        assertEquals(anotherCarnivore, guard.getHuntedAnimal(), "Guard should switch to new target");
    }

    @Test
    public void testGuardShootsHunterInRange() {
        // Guard and hunter are close (< 40)
        guard.setX(210);
        guard.setY(210);
        guard.setHuntedHunter(hunter);

        guard.shootIfClose(hunter, 40);

        assertFalse(GameEngine.mapData.hunters.contains(hunter), "Hunter should be shot and removed");
        assertNull(guard.getHuntedHunter(), "Guard should clear hunter target after shooting");
    }

    @Test
    public void testGuardDoesNotShootHunterOutOfRange() {
        guard.setX(100);
        guard.setY(100);
        guard.setHuntedHunter(hunter);

        guard.shootIfClose(hunter, 10); // too far

        assertTrue(GameEngine.mapData.hunters.contains(hunter), "Hunter should still be present");
        assertEquals(hunter, guard.getHuntedHunter(), "Guard should still have hunter as target");
    }
}
