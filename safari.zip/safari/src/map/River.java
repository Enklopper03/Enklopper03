package src.map;

import javax.swing.*;
import java.awt.*;



/**
 * A River osztály a folyót reprezentálja a térképen.
 * A folyó egy olyan akadály, amely egy adott helyet foglal el a térképen.
 * A folyó képe a "river.png" fájlból töltődik be.
 */
public class River extends Obstacle {

    private int health = 200;

    /**
     * Konstruktor, amely inicializálja a folyó pozícióját, méretét és képét.
     *
     * @param x      A folyó vízszintes koordinátája.
     * @param y      A folyó függőleges koordinátája.
     * @param width  A folyó szélessége.
     * @param height A folyó magassága.
     */
    public River(int x, int y, int width, int height) {

        super(x, y, width, height, new ImageIcon("src/main/resources/river.png").getImage());
    }

    public int getHealth() {
        return health;
    }

    public void decreaseHealth(int amount) {
        health -= amount;
    }

    public boolean isDead() {
        return health <= 0;
    }

}
