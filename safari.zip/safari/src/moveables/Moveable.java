package src.moveables;
import src.utils.Direction;

import java.awt.*;



/**
 * Az Moveable osztály egy absztrakt osztály, amely a mozgatható objektumokat reprezentálja.
 * Az osztály tartalmazza a mozgatható objektumok közös tulajdonságait és metódusait.
 */
public abstract class  Moveable {

    private int x;
    private int y;
    private  int width;
    private  int height;
    private Image image;

    public Moveable(int x, int y, Direction directionX, Direction directionY, int width, int height, Image image) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }


    /* * A mozgatható objektum képének beállítása.
     *
     * @param image Az új kép, amelyet beállítunk.
     */
    public void draw(Graphics2D g2d) {
        g2d.drawImage(image, (int) x, (int) y, width, height, null);
    }


    /**
     * A mozgatható objektum mozgasanak absztrakt metódusa.
     */
    public abstract void move();

}
