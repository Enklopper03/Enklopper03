from django.contrib import admin
from .models import DomainDecision

@admin.register(DomainDecision)
class DomainDecisionAdmin(admin.ModelAdmin):
    list_display = ['domain', 'decision', 'number', 'generated_at']
