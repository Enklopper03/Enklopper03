<?php

namespace App\Http\Controllers;
use App\Models\Animal;
use App\Models\Enclosure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class AnimalController extends Controller
{

    public function create()
    {
        $enclosures = Enclosure::all(); // Összes kifutó lekérdezése
        return view('animals.create', compact('enclosures'));
    }

public function store(Request $request)
{
    // Csak admin!
    if (!auth()->user()->admin) {
        abort(403);
    }

    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'species' => 'required|string|max:255',
        'is_predator' => 'required|in:0,1',
        'born_at' => 'required|date',
        'image' => 'required|image|max:2048', // max 2MB kép
        'enclosure_id' => 'required|exists:enclosures,id',

    ]);

    $enclosure = Enclosure::findOrFail($validated['enclosure_id']);

    // Ellenőrzés ragadozó és nem ragadozó keveredésre
    $existingPredators = $enclosure->animals()->where('is_predator', 1)->exists();
    $existingNonPredators = $enclosure->animals()->where('is_predator', 0)->exists();

    if (($validated['is_predator'] && $existingNonPredators) || (!$validated['is_predator'] && $existingPredators)) {
        return back()->withErrors(['enclosure_id' => 'Ebben a kifutóban nem keverhetők a ragadozók és nem ragadozók!'])->withInput();
    }

    // Kép feltöltés
    if ($request->hasFile('image')) {
        $validated['image'] = $request->file('image')->store('animals', 'public');
    }

    Animal::create($validated);

    return redirect()->route('enclosures.show', $validated['enclosure_id'])->with('success', 'Állat sikeresen létrehozva!');
}


public function edit(Animal $animal)
{
    // Csak adminok férhetnek hozzá
    if (!auth()->user()->admin) {
        abort(403);
    }

    $enclosures = Enclosure::all();  // Az összes kifutó lekérdezése
    return view('animals.edit', compact('animal', 'enclosures'));
}



public function update(Request $request, Animal $animal)
{
    // Csak adminok férhetnek hozzá
    if (!auth()->user()->admin) {
        abort(403);
    }

    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'species' => 'required|string|max:255',
        'is_predator' => 'required|boolean',
        'born_at' => 'required|date',
        'image' => 'required|image|max:2048', // max 2MB kép
        'enclosure_id' => 'required|exists:enclosures,id',
    ]);

    // Kép cserélés esetén töröljük a régi képet
    if ($request->hasFile('image')) {
        // Ha van új kép, először töröljük a régit
        if ($animal->image) {
            Storage::delete('public/' . $animal->image);
        }

        // Új kép tárolása
        $validated['image'] = $request->file('image')->store('animals', 'public');
    }

    // Az állat adatainak frissítése
    $animal->update($validated);

    return redirect()->route('enclosures.show', $animal->enclosure_id)->with('success', 'Állat sikeresen módosítva!');
}


public function archive(Animal $animal)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    // Az állat áthelyezése az "Örök vadászmező" kifutóba, mielőtt archiválnánk
    $eternalEnclosure = Enclosure::where('name', 'Örök vadászmező')->first();
    $animal->enclosure_id = $eternalEnclosure->id;
    $animal->save();

    // Archiválás
    $animal->delete();

    return redirect()->route('enclosures.show',  $animal->enclosure_id)->with('success', 'Állat sikeresen archiválva!');
}
public function archived()
    {
        if (!auth()->user()->admin) {
            abort(403);
        }

        $animals = Animal::onlyTrashed()
            ->orderByDesc('deleted_at')
            ->get();

        $enclosures = Enclosure::all(); // Kifutók listája a visszaállításhoz

        return view('animals.archived', compact('animals', 'enclosures'));
    }

    // Archivált állat visszaállítása
    public function restore(Request $request, $id)
    {
        if (!auth()->user()->admin) {
            abort(403);
        }

        $request->validate([
            'enclosure_id' => 'required|exists:enclosures,id',
        ]);

        $animal = Animal::onlyTrashed()->findOrFail($id);

        $animal->enclosure_id = $request->input('enclosure_id');
        $animal->restore(); // soft delete visszaállítása
        $animal->save();    // kifutó frissítése

        return redirect()->route('animals.archived')->with('success', 'Állat sikeresen visszaállítva!');
    }

}



