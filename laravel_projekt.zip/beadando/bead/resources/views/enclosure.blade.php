@extends('layouts.app')

@section('content')
    <div class="container">
        @if($enclosures->count() > 0)
            <table class="table">
                <thead>
                    <tr>
                        <th>Név</th>
                        <th></th>
                        <th>Limit</th>
                        <th></th>
                        <th>Állatok száma</th>
                        <th></th>
                        <th>Akciók</th>
                        @auth
                            @if(auth()->user()->admin)
                            <th><a href="{{ route('enclosures.create') }}" class="btn btn-warning">Létrehozás</a></th>
                            @endif
                        @endauth
                    </tr>
                </thead>
                <tbody>
                    @foreach($enclosures as $enclosure)
                        <tr>
                            <td>{{ $enclosure->name }}</td>
                            <td></td>
                            <td>{{ $enclosure->limit }}</td>
                            <td></td>
                            <td>{{ $enclosure->animals_count }}</td>
                            <td></td>
                            <td>
                                <a href="{{ route('enclosures.show',  $enclosure->id) }}" class="btn btn-warning">Megjelenítés</a></th>

                                @auth
                                    @if(auth()->user()->admin)
                                        <a href="{{ route('enclosures.edit', $enclosure->id) }}" class="btn btn-warning">Szerkesztés</a>

                                        <form action="{{ route('enclosures.destroy', $enclosure->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Biztosan törölni akarod ezt a kifutót?');">Törlés</button>
                                        </form>
                                        <form action="{{ route('enclosures.clear', $enclosure->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            <button type="submit" class="btn btn-danger">Ürítés</button>
                                        </form>



                                    @endif
                                @endauth
                            </td>

                        </tr>
                    @endforeach
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif
                </tbody>
            </table>

            {{ $enclosures->links() }}
        @else
            <p>Nincsenek rendelt kifutók.</p>
        @endif

        {{-- <!-- Debug: Kiírja az enclosures változót -->
        <h3>Debug Enclosures:</h3>
        <pre>{{ print_r($enclosures, true) }}</pre> --}}

    </div>
@endsection
