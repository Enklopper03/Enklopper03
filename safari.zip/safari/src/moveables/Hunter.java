package src.moveables;
import src.main.GameEngine;
import  src.utils.Direction;

import javax.swing.*;
import java.awt.*;
import java.util.Random;


/**
 * A Hunter (vadász) osztály a térképen található vadászokat reprezentálja.
 * A vadász képes vadászni a növényevők (Herbivore) ellen, és képes elrejteni magát.
 */
public class Hunter extends Moveable{
    private double speed = 0.2;
    public void setSpeed(double speed) {
        this.speed = speed;
    }
    private  boolean isInvisible = true;
    private Herbivore targetHerbivore;
    private Rectangle hitbox;
    public boolean showHitbox = false;
    public void setShowHitbox(boolean showHitbox) { this.showHitbox = showHitbox; }
    public Rectangle createHitbox() {
        return new Rectangle(getX(), getY(), getWidth(), getHeight());
    }
    public void updateHitbox() {
        this.hitbox = createHitbox();
    }

    public boolean isInvisible() {
        return isInvisible;
    }
    public void setInvisible(boolean invisible) {
        this.isInvisible = invisible;
    }


    /**
     * Konstruktor, amely inicializálja a vadász pozícióját, irányát, sebességét, méretét és képét.
     *
     * @param x           A vadász vízszintes koordinátája.
     * @param y           A vadász függőleges koordinátája.
     * @param directionX  A vadász vízszintes iránya.
     * @param directionY  A vadász függőleges iránya.
     * @param speed       A vadász sebessége.
     * @param width       A vadász szélessége.
     * @param height      A vadász magassága.
     */
    public Hunter(int x, int y, Direction directionX, Direction directionY, int speed, int width, int height) {
        super(x, y, directionX, directionY, width, height, new ImageIcon("src/main/resources/hunter.png").getImage());
    }


    /**
     * A vadász eltalál egy növényevőt (Herbivore) és eltávolítja azt a listából.
     *
     * @param herbivore A lelőni kívánt növényevő.
     */
    public void shoot(Herbivore herbivore) {
        if (GameEngine.mapData.herbivores.contains(herbivore) || GameEngine.herbivores.contains(herbivore)) {
            GameEngine.mapData.herbivores.remove(herbivore);
            GameEngine.herbivores.remove(herbivore);
            System.out.println("HERBIVORE HAS BEEN SHOT");
        } else {
            System.out.println("HERBIVORE NOT FOUND IN THE LIST");
        }
    }

    /**
     * A vadász véletlenszerűen kiválaszt egy növényevőt (Herbivore), hogy azt üldözze.
     * Ha nincs elérhető növényevő, null értéket állít be.
     */
    public void chooseRandomHerbivore() {
        if (!GameEngine.mapData.herbivores.isEmpty()) {
            Random random = new Random();
            targetHerbivore = GameEngine.mapData.herbivores.get(random.nextInt(GameEngine.mapData.herbivores.size()));
            System.out.println("Hunter is now targeting a herbivore.");
        } else {
            targetHerbivore = null;
            System.out.println("No herbivores available to target.");
        }
    }


    /**
     * A vadász mozgása a választott növényevő (Herbivore) felé.
     * Ha a távolság kisebb, mint 5, a vadász lelövi a növényevőt.
     */
    @Override
    public void move() {
        Random random = new Random();
        if (targetHerbivore == null && random.nextInt(1000) < 5) {
            chooseRandomHerbivore();
        }
        if (targetHerbivore != null) {
            int hunterX = getX();
            int hunterY = getY();
            int targetX = targetHerbivore.getX();
            int targetY = targetHerbivore.getY();

            double dx = targetX - hunterX;
            double dy = targetY - hunterY;

            double distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 5) {
                shoot(targetHerbivore);
                this.targetHerbivore = null; // Reset target after shooting
                return;
            }

            // Normalize and apply speed
            double moveX = (dx / distance) * speed;
            double moveY = (dy / distance) * speed;

            setX((int) (hunterX + moveX));
            setY((int) (hunterY + moveY));
        }
    }


    /**
     * Kirajzolja a vadászt a megadott Graphics2D objektummal.
     *
     * @param g2d A grafikai objektum, amelyre a vadász képe lesz rajzolva.
     */
    @Override
    public void draw(Graphics2D g2d) {
        super.draw(g2d);

        if (showHitbox) {
            updateHitbox();
            Graphics2D g2dd = (Graphics2D) g2d;
            g2dd.setColor(Color.RED);
            g2dd.draw(hitbox);
        }
    }
}
