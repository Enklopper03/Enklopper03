@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Kifutó szerkesztése</h2>

    <form method="POST" action="{{ route('enclosures.update', $enclosure->id) }}">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label for="name" class="form-label">Név</label>
            <input type="text" name="name" id="name" class="form-control" value="{{ old('name', $enclosure->name) }}" required>
            @error('name')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="limit" class="form-label">Állat limit</label>
            <input type="number" name="limit" id="limit" class="form-control" min="1" value="{{ old('limit', $enclosure->limit) }}" required>
            @error('limit')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="feeding_at" class="form-label">Etetés ideje (HH:MM)</label>
            <small class="text-muted">Pl: 08:00:00</small>
            <input type="text" name="feeding_at" id="feeding_at" class="form-control" placeholder="HH:MM:SS" value="{{ old('feeding_at') }}" required>
            @error('feeding_at')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="user_ids" class="form-label">Gondozók kiválasztása</label>
            <select name="user_ids[]" id="user_ids" class="form-control" multiple required>
                @foreach($users as $user)
                    <option value="{{ $user->id }}" {{ in_array($user->id, old('user_ids', $selectedUsers)) ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->email }})
                    </option>
                @endforeach
            </select>
            @error('user_ids')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Frissítés</button>
    </form>
</div>
@endsection
