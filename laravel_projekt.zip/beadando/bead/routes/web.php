<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EnclosureController;
use App\Http\Controllers\AnimalController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// A főoldal route-ja (csak bejelentkezett felhasználóknak)
Route::middleware(['auth', 'verified'])->get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::middleware(['auth', 'verified'])->get('/enclosure', [EnclosureController::class, 'index'])->name('enclosure');


Route::middleware(['auth'])->group(function () {
    Route::get('/enclosure/create', [EnclosureController::class, 'create'])->name('enclosures.create');
    Route::post('/enclosure', [EnclosureController::class, 'store'])->name('enclosures.store');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/animals/create', [AnimalController::class, 'create'])->name('animals.create');
    Route::post('/animals', [AnimalController::class, 'store'])->name('animals.store');
});



Route::get('/enclosures/{id}', [EnclosureController::class, 'show'])->name('enclosures.show');


Route::get('/enclosures/{enclosure}/edit', [EnclosureController::class, 'edit'])->name('enclosures.edit');
Route::put('/enclosures/{enclosure}', [EnclosureController::class, 'update'])->name('enclosures.update');


Route::middleware(['auth'])->group(function () {
    Route::get('/animals/{animal}/edit', [AnimalController::class, 'edit'])->name('animals.edit');
    Route::put('/animals/{animal}', [AnimalController::class, 'update'])->name('animals.update');
});


Route::delete('/animals/{animal}/archive', [AnimalController::class, 'archive'])->name('animals.archive');

// Archivált állatok listája
Route::get('/animals/archived', [AnimalController::class, 'archived'])->name('animals.archived');

// Állat visszaállítása
Route::post('/animals/{animal}/restore', [AnimalController::class, 'restore'])->name('animals.restore');


// EnclosureController kiürítés funkció
Route::post('enclosures/{id}/clear', [EnclosureController::class, 'clear'])->name('enclosures.clear');

Route::delete('/enclosures/{enclosure}', [EnclosureController::class, 'destroy'])->name('enclosures.destroy');






// A felhasználói profil kezelése
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
