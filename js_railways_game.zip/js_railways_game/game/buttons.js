window.addEventListener('load', () => {
    
  

    document.querySelectorAll('.difficulty-button').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.difficulty-button').forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            selectedDifficulty = button.dataset.difficulty;
            console.log(`Kiválasztott nehézség: ${selectedDifficulty}`);
        });
    });


    const modal = document.querySelector('#game-description-modal');
    const closeButton = document.querySelector('.close-button');

    document.querySelector('.menu-button[data-target="game-description"]').addEventListener('click', () => {
        modal.style.display = 'block';
    });

    closeButton.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    document.querySelector('#start-game-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const playerName = document.querySelector('#player-name').value;
        const difficultyButton = document.querySelector('.difficulty-button.active');
        const errorMessage = document.querySelector('#error-message');
    
        if (!playerName) {
            errorMessage.textContent = 'Nincs megadva játékosnév';
            errorMessage.style.display = 'block';
            return;
        }
    
        if (!difficultyButton) {
            errorMessage.textContent = 'Nincs kiválasztva nehézségi szint';
            errorMessage.style.display = 'block';
            return;
        }
    
        const difficulty = difficultyButton.dataset.difficulty;
        startGame(playerName, difficulty);
    
        // Megjelenítjük a game-info divet és elrejtjük a start-game és main-menu divet
        document.querySelector('#game-info2').style.display = 'block';
        document.querySelector('#game-info').style.display = 'block';
        document.querySelector('#game-board').style.display = 'block';
        document.querySelector('#start-game').style.display = 'none';
        document.querySelector('#main-menu').style.display = 'none';
        // document.querySelector('#check-solution').style.display = 'block'; 
        document.querySelector('h1').style.display = 'none'; // Elrejtjük a h1 elemet
        errorMessage.style.display = 'none'; // Elrejtjük a hibaüzenetet, ha minden rendben van
    });

});

document.querySelector('#start-game-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const playerName = document.querySelector('#player-name').value;
    const difficultyButton = document.querySelector('.difficulty-button.active');
    const errorMessage = document.querySelector('#error-message');

    if (!playerName) {
        errorMessage.textContent = 'Nincs megadva játékosnév';
        errorMessage.style.display = 'block';
        return;
    }

    if (!difficultyButton) {
        errorMessage.textContent = 'Nincs kiválasztva nehézségi szint';
        errorMessage.style.display = 'block';
        return;
    }

    const difficulty = difficultyButton.dataset.difficulty;
    startGame(playerName, difficulty);

    // Megjelenítjük a game-info divet és elrejtjük a start-game és main-menu divet
    document.querySelector('#game-info').style.display = 'block';
    document.querySelector('#game-board').style.display = 'block';
    // document.querySelector('#check-solution').style.display = 'block'; // Megjelenítjük az ellenőrzés gombot
    document.querySelector('#save-state').style.display = 'block'; // Megjelenítjük a mentés gombot
    document.querySelector('#load-state').style.display = 'block'; // Megjelenítjük a betöltés gombot
    document.querySelector('#back').style.display = 'block';
    document.querySelector('#game-board-container').style.display = 'block';
    document.querySelector('#start-game').style.display = 'none';
    document.querySelector('#main-menu').style.display = 'none';
    document.querySelector('#toplist-container').style.display = 'none';
    document.querySelector('#check-solution').style.display = 'block';
    document.querySelector('h1').style.display = 'none'; // Elrejtjük a h1 elemet
    // document.querySelector('button-container').style.display = 'block';
    errorMessage.style.display = 'none'; // Elrejtjük a hibaüzenetet, ha minden rendben van
});

document.querySelector('#back').addEventListener('click', () => {
    document.querySelector('#game-info2').style.display = 'none';
    document.querySelector('#game-board-container').style.display = 'none';
    document.querySelector('#game-info').style.display = 'none';
    document.querySelector('#game-board').style.display = 'none';
    document.querySelector('#save-state').style.display = 'none';
    document.querySelector('#back').style.display = 'none';
    document.querySelector('#start-game').style.display = 'block';
    document.querySelector('#main-menu').style.display = 'block';
    document.querySelector('h1').style.display = 'block';
    document.querySelector('#message').style.display = 'none';

    // Leállítjuk az időzítőt
    if (timerInterval) {
        clearInterval(timerInterval);
    }
});

document.querySelector('#save-state').addEventListener('click', () => {
    const state = [];
    document.querySelectorAll('.cell').forEach(cell => {
        const row = cell.dataset.row;
        const col = cell.dataset.col;
        const type = cell.dataset.type;
        const fixed = cell.dataset.fixed || false;
        const track = cell.querySelector('.rail-track');
        const trackType = track ? track.src.split('/').pop() : null;
        const rotation = track ? track.dataset.rotation : null;
        state.push({ row, col, type, fixed, trackType, rotation });
    });
    localStorage.setItem('gameState', JSON.stringify(state));
    const messageDiv = document.querySelector('#message');
    messageDiv.textContent = 'Játékállapot elmentve.';
    messageDiv.style.display = 'block';
});

document.querySelector('#load-state').addEventListener('click', () => {
    function rotate(deg) {
        return `rotate(${deg})`;
    }
    const state = JSON.parse(localStorage.getItem('gameState'));
    if (state) {
        state.forEach(cellState => {
            const cell = document.querySelector(`.cell[data-row="${cellState.row}"][data-col="${cellState.col}"]`);
            cell.dataset.type = cellState.type;
            if (cellState.fixed) {
                cell.dataset.fixed = cellState.fixed;
            }
            if (cellState.trackType) {
                const railTrack = document.createElement('img');
                railTrack.src = `../pics/tiles/${cellState.trackType}`;
                railTrack.classList.add('rail-track');
                railTrack.dataset.rotation = cellState.rotation;
                railTrack.style.transform = rotate(`${cellState.rotation}deg`);
                cell.appendChild(railTrack);

                // Hozzáadjuk az eseménykezelőket a betöltött sínekhez
                railTrack.addEventListener('click', (event) => {
                    event.preventDefault();
                    if (event.button === 0) { // Bal klikk
                        if (railTrack.src.includes('straight_rail.png')) {
                            railTrack.src = '../pics/tiles/curve_rail.png';
                        } else {
                            railTrack.src = '../pics/tiles/straight_rail.png';
                        }
                    }
                });

                railTrack.addEventListener('contextmenu', (event) => {
                    event.preventDefault();
                    const currentRotation = parseInt(railTrack.dataset.rotation) || 0;
                    const newRotation = (currentRotation + 90) % 360;
                    railTrack.style.transform = rotate(`${newRotation}deg`);
                    railTrack.dataset.rotation = newRotation;
                });

                railTrack.addEventListener('mousedown', (event) => {
                    if (event.button === 1) { // Középső klikk
                        event.preventDefault();
                        cell.removeChild(railTrack);
                    }
                });
            }
        });
        const messageDiv = document.querySelector('#message');
        messageDiv.textContent = 'Játékállapot betöltve.';
        messageDiv.style.display = 'block';
    } else {
        const messageDiv = document.querySelector('#message');
        messageDiv.textContent = 'Nincs elmentett játékállapot.';
        messageDiv.style.display = 'block';
    }
});

