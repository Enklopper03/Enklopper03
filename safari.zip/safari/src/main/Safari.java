package src.main;

import src.main.SafariGUI;

import java.io.IOException;


/**
 *Meghívja a safariGUI osztalyt konkstruktoraba
 */
public class Safari {
    public static void main(String[] args) throws IOException {
        SafariGUI gui = new SafariGUI();
    }
}
