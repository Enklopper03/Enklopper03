<template>
    <img src="../assets/img/hatterjo2.jpg" class="img-fluid" alt="lemez" />
    
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>
