package src.main;

import src.map.*;
import src.moveables.*;
import src.utils.Direction;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;
import java.awt.event.*;
/**
 * A {@code GameEngine} osztály a játék fő motorja és megjelenítő felülete.
 *
 * Ez az osztály felelős:
 * <ul>
 *     <li>a játék logikájának vezérléséért,</li>
 *     <li>az állatok mozgásáért és viselkedéséért,</li>
 *     <li>az időciklusok (nappal-éjszaka) kezeléséért,</li>
 *     <li>valamint a térkép elemeinek (növények, tavak stb.) frissítéséért és eltávolításáért.</li>
 * </ul>
 *
 * Az osztály kiterjeszti a {@link JPanel} komponenst, ezáltal képes grafikus megjelenítésre a Swing keretrendszerben.
 */


public class GameEngine extends JPanel {

    //TIMER VALTOZOK
    /** Képkockák száma másodpercenként (FPS), amely alapján a játék időzítése történik. */
    private final int FPS = 30;

    /** Az aktuális nap számlálója. Minden nap elteltével növekszik. */
    public int dayCount = 1;

    /** A sikeres napok (pl. célok teljesítése) egymás utáni száma. */
    public int streakCount = 0;

    /** A játékos által birtokolt pénzösszeg. */
    public static int money = 10000;

    /** A belépőjegy ára a játékban. */
    private int entryPrice = 100;


    /** Az időzítő tick-jeinek száma, a játék frissítéséhez. */
    private int tickCounter = 0;

    /** A nappali és éjszakai időszakok hossza képkockákban. */
    private final int dayDuration = 20 * FPS;
    private final int nightDuration = 10 * FPS;

    /** Az aktuális időszak hossza képkockákban. */
    public int currentPhaseDuration = dayDuration; // indulásnál nappal van


    /** Az összes állat listája, beleértve a növényevőket és a húsevőket is. */
    private List<Animal> allAnimals;


    /** A játék nehézségi szintje (pl. "easy", "medium", "hard"). */
    public String difficulty;

    /** A pálya adatait tartalmazó objektum, például fák, tavak, utak stb. */
    public static MapData mapData;

    /** A fűfoltok listája, amiket a növényevők táplálkozásra használhatnak. */
    private List<Grass> grassyAreas;

    /** A játékban szereplő növényevők listája. */
    public static List<Herbivore> herbivores;

    /** A játékban szereplő húsevők listája. */
    public static List<Carnivore> carnivores;

    /** A játékban lerakott dzsippek listája. */
    public static List<Jeep> jeeps;

    /** A játékban lerakott őrök listája. */
    public static List<Guard> guards;

    private final Image background;
    private boolean isDaylight = true; // switches background image of the icon between sun and moon
    private Timer gameTimer;
    private int cellSize = 50;
    private String ghostType;
    private Image ghostImage;
    private Point ghostPosition;
    private boolean isPlacing = false;
    private final int locatorPrice = 70;


    // JATEKPALYAN MEGJELENES
    /** A jatekpalyan megjeleno eheto es ihato objektumok listaja,  */
    private List<Lake> discoveredDrinks1;
    private List<Lake> discoveredDrinks2;
    private List<River> discoveredRivers;
    private List<Herbivore> discoveredFood;
    private List<Tree> discoveredTrees;
    private List<Bush> discoveredBushes;


    // Megjelenites toolbar stb
    /** A jatekpalyan megjeleno grafikai elemek  */

    private JToolBar toolbar;
    private JButton manageButton, speedButton, shopButton;
    private JLabel streakLabel, dayLabel, moneyLabel, dayNightLabel;
    private JPanel actionPanel;
    private JPanel overlayPanel;
    private boolean isActionPanelOpen = false;
    public int speed = 1;

    // Hivatkozasok
    String levelPath;


    /**
     * A GameEngine konstruktora, amely inicializálja a játékot a megadott nehézségi szinten.
     *
     * Beállítja a kezdő értékeket, például az állatlistákat, háttérképet, időzítőt és
     * a felhasználói interakciókat (egér, mozgás stb.). A játék itt indul el, és az első pálya is itt töltődik be.
     *
     * @param difficulty A választott nehézségi szint (pl. "easy", "medium", "hard").
     */
    public GameEngine(String difficulty) {
        this.difficulty = difficulty;
        this.discoveredTrees = new ArrayList<>();
        this.discoveredBushes = new ArrayList<>();
        this.discoveredDrinks1 = new ArrayList<>();
        this.discoveredDrinks2 = new ArrayList<>();
        this.discoveredRivers = new ArrayList<>();
        this.grassyAreas = new ArrayList<>();
        this.herbivores = new ArrayList<>();
        this.carnivores = new ArrayList<>();
        this.jeeps = new ArrayList<>();
        this.guards = new ArrayList<>();


        this.discoveredFood = new ArrayList<>();

        setFocusable(true);
        setPreferredSize(new Dimension(1900, 1450));
        setLayout(new BorderLayout());

        Random r = new Random();
        int level = r.nextInt(9);
        levelPath = "src/main/levels/level" + level + ".txt";
        background = new ImageIcon("src/main/resources/grassbg.jpg").getImage();

        gameTimer = new Timer(1000 / FPS, e -> {
            if (tickCounter % (FPS * 3) == 0) {
                for (Herbivore h : herbivores) {
                    h.maybeUpdateDestinations(new ArrayList<>(herbivores), allAnimals, 1420, 980);
                    h.checkStuckAndRedirect(200, 200);
                    if (h.isFull()) {
                        h.rest();
                    }
                }
                for (Carnivore c : carnivores) {
                    c.maybeUpdateDestinations(new ArrayList<>(carnivores), allAnimals, 1420, 980);
                    c.checkStuckAndRedirect(200, 200);
                    if (c.isFull()) {
                        c.rest();
                    }
                }
            }
            for (Jeep j : jeeps) {
                if (!j.isMoving() && r.nextInt(0, 5) == 0) {
                    j.addPassenger();
                }
            }

            // 🔹 Gyűjtjük az új állatokat külön listákba
            List<Herbivore> newHerbivores = new ArrayList<>();
            List<Carnivore> newCarnivores = new ArrayList<>();

            for (Herbivore h : herbivores) {
                sendHungryHerbivoreToKnownFood(h);
                sendThirstyHerbivoreToKnownWater(h);
                if (h.getDestination() != null)
                    h.moveTowards(h.getDestination(), speed);
                h.adjustTowardsHerd(herbivores);
                h.ageUp();
                Animal baby = h.breed(new ArrayList<>(herbivores));
                if (baby instanceof Herbivore newHerbivore) {
                    newHerbivores.add(newHerbivore);
                    allAnimals.add(newHerbivore);
                    System.out.println("Új herbivore született!");
                }
            }

            for (Carnivore c : carnivores) {
                if (c.getDestination() != null)
                    c.moveTowards(c.getDestination(), speed);
                c.adjustTowardsHerd(carnivores);
                c.ageUp();
                Animal baby = c.breed(new ArrayList<>(carnivores));
                if (baby instanceof Carnivore newCarnivore) {
                    newCarnivores.add(newCarnivore);
                    allAnimals.add(newCarnivore);
                    System.out.println("Új carnivore született!");
                }
            }

            // 🔹 Iteráció után hozzáadjuk őket a fő listákhoz
            herbivores.addAll(newHerbivores);
            carnivores.addAll(newCarnivores);

            moneyLabel.setText("Money: " + money);
            moveGuard();
            moveHunter();
            moveJeep();
            updateDayProgress();
            setDiscoveredFoodAndDrinks();
            checkAndRemoveThings();
            checkWinCondition();
            repaint();
        });
        try {
            this.mapData = new MapData("src/main/levels/level0.txt");
        } catch (IOException e) {
            Logger.getLogger(GameEngine.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
        }

        createToolbar();
        gameTimer.start();
        startGame();
        setDiscoveredFoodAndDrinks();
        repaint();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int mouseX = e.getX();
                int mouseY = e.getY();

                for (Guard guard : mapData.guards) {
                    if (isClicked(guard, mouseX, mouseY)) {
                        handleGuardClick(guard);
                        break;
                    }
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                if (isPlacing) {
                    ghostPosition = e.getPoint();
                    repaint();
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (isPlacing) {
                    placeItemAt(e.getPoint());
                    ghostType = null;
                    isPlacing = false;
                    ghostImage = null;
                    repaint();
                }
            }
        });
    }


    /**
     * Egy adott növényevő számára megpróbál ismert táplálékforrást keresni.
     * Ha az állat éhes és nincs célállomása, prioritási sorrend alapján próbál ételt találni.
     *
     * @param h A növényevő állat, amely éhes lehet.
     */
    private void sendHungryHerbivoreToKnownFood(Herbivore h) {
        if (h.isHungry() && h.getDestination() == null) {
            if (!discoveredBushes.isEmpty()) {
                h.setDestination(discoveredBushes.get(0).getPosition());
            } else if (!discoveredTrees.isEmpty()) {
                h.setDestination(discoveredTrees.get(0).getPosition());
            } else if (!grassyAreas.isEmpty()) {
                h.setDestination(grassyAreas.get(0).getPosition());
            }
        }
    }


    /**
     * Elindítja a játékot az alapértelmezett (első) pálya betöltésével.
     *
     * Betölti a pályaelemeket a fájlból, és inicializálja az állatokat.
     * Hibakezelést alkalmaz, ha a pályafájl nem érhető el vagy hibás.
     */
    private void startGame() {
        try {
            this.mapData = new MapData("src/main/levels/level0.txt");
            this.allAnimals = new ArrayList<>();
            allAnimals.addAll(mapData.herbivores);
            allAnimals.addAll(mapData.carnivores);
            this.herbivores = mapData.herbivores;
            this.carnivores = mapData.carnivores;
            this.allAnimals = new ArrayList<>();
            allAnimals.addAll(herbivores);
            allAnimals.addAll(carnivores);

        } catch (IOException e) {
            Logger.getLogger(GameEngine.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
        }
    }

    /**
     * Ellenőrzi és eltávolítja a pályáról azokat az objektumokat, amelyek "meghaltak" vagy elhasználódtak.
     *
     * Ide tartoznak a bokrok, fák, füvek, tavak, folyók, valamint az elpusztult állatok.
     * Minden egyes eltávolítást naplóz (kiírja a konzolra).
     */
    public void checkAndRemoveThings() {
        mapData.bushes.removeIf(b -> {
            if (b.isDead()) {
                System.out.println("Bush removed");
                return true;
            }
            return false;
        });

        mapData.trees.removeIf(t -> {
            if (t.isDead()) {
                System.out.println("Tree removed");
                return true;
            }
            return false;
        });

        mapData.grassyAreas.removeIf(g -> {
            if (g.isDead()) {
                System.out.println("Grass removed");
                return true;
            }
            return false;
        });
        mapData.herbivores.removeIf(h -> {
            if (h.isDead()) {
                System.out.println("Herbivore removed");
                return true;
            }
            return false;
        });

        mapData.carnivores.removeIf(c -> {
            if (c.isDead()) {
                System.out.println("Carnivore removed");
                return true;
            }
            return false;
        });


        mapData.lakes.removeIf(l -> {
            if (l.isDead()) {
                System.out.println("Lake removed");
                return true;
            }
            return false;
        });

        mapData.rivers.removeIf(r -> {
            if (r.isDead()) {
                System.out.println("River removed");
                return true;
            }
            return false;
        });
    }


    /**
     * Megpróbálja a szomjas növényevőt a legközelebbi ismert tóhoz irányítani.
     *
     * Ha az állat szomjas és nincs célpontja, kiválasztja a hozzá legközelebbi tavat a
     * korábban felfedezettek közül, majd beállítja azt célállomásként.
     *
     * @param h A szomjas növényevő állat.
     */
    private void sendThirstyHerbivoreToKnownWater(Herbivore h) {
        if (!h.isThirsty() || h.getDestination() != null)
            return;

        Lake closestLake = null;
        double closestDistance = Double.MAX_VALUE;

        for (Lake lake : discoveredDrinks1) {
            double distance = h.getPosition().distance(lake.getCenter());
            if (distance < closestDistance) {
                closestDistance = distance;
                closestLake = lake;
            }
        }

        if (closestLake != null) {
            h.setDestination(closestLake.getCenter());
            System.out.println("Herbivore célba vette a tavat: " + closestLake.getCenter());
        }
    }


    /**
     * Frissíti az állatok által felfedezett élelem- és vízforrásokat.
     *
     * Ez a metódus minden herbivorra és carnivorra külön-külön végigmegy,
     * és ha ezek ütköznek fával, bokorral, fűvel, tóval vagy folyóval,
     * hozzáadja őket a felfedezett listához. Éhség vagy szomjúság esetén
     * az állat azonnal enni vagy inni próbál, illetve lassítja őket dombon vagy vízben.
     */
    public void setDiscoveredFoodAndDrinks() {
        for (Herbivore h : herbivores) {
            boolean isInRiver = false;
            boolean isOnHill = false;// Iterate through all herbivores
            for (Tree tree : mapData.trees) {
                if (h.getHitbox().intersects(tree.getHitbox())) {
                    if (!discoveredTrees.contains(tree)) { // Avoid duplicates
                        System.out.println("Herbivore hit a tree!");
                        discoveredTrees.add(tree);
                        if (h.isHungry()) {
                            h.setDestination(tree.getPosition());
                            h.moveTowards(tree.getPosition(), speed);
                            h.eat(discoveredTrees, discoveredBushes, grassyAreas);
                        }

                    }
                }
            }

            for (Hill hill : mapData.hills) {
                if (h.getHitbox().intersects(hill.getHitbox())) {// Avoid duplicates
                        isOnHill = true;
                    }

                }

            // Ha bent van dombban → lassítsuk le
            if (isOnHill) {
                h.setSpeed(h.getSpeed() / 2); //
            } else {
                h.resetSpeed(); // visszaáll az eredeti sebesség
            }

            for (River river : mapData.rivers) {
                if (h.getHitbox().intersects(river.getHitbox())) {
                    if (!discoveredRivers.contains(river)) { // Avoid duplicates
                        System.out.println("Herbivore hit a river!");
                        discoveredRivers.add(river);
                    }

                    if (h.isThirsty()) {
                        h.setDestination(river.getPosition());
                        h.moveTowards(river.getPosition(), speed);
                        h.drink(discoveredDrinks1, discoveredRivers);
                    }
                    isInRiver = true;
                }

            }

            // Ha bent van folyóban → lassítsuk le
            if (isInRiver) {
                h.setSpeed(h.getSpeed() / 2); //
            } else {
                h.resetSpeed(); // visszaáll az eredeti sebesség
            }

            for (Grass grass : mapData.grassyAreas) {
                if (h.getHitbox().intersects(grass.getHitbox())) {
                    if (!grassyAreas.contains(grass)) { // Avoid duplicates
                        System.out.println("Herbivore hit a grassy area!");
                        grassyAreas.add(grass);
                        h.setDestination(grass.getPosition());
                        if (h.isHungry()) {
                            h.setDestination(grass.getPosition());
                            h.moveTowards(grass.getPosition(), speed);
                            h.eat(discoveredTrees, discoveredBushes, grassyAreas);
                        }
                    }
                }
            }

            for (Bush bush : mapData.bushes) {
                if (h.getHitbox().intersects(bush.getHitbox())) {
                    if (!discoveredBushes.contains(bush)) { // Avoid duplicates
                        System.out.println("Herbivore hit a bush!");
                        discoveredBushes.add(bush);
                        h.setDestination(bush.getPosition());
                        if (h.isHungry()) {
                            h.setDestination(bush.getPosition());
                            h.moveTowards(bush.getPosition(), speed);
                            h.eat(discoveredTrees, discoveredBushes, grassyAreas);
                        }
                    }
                }
            }
            for (Lake lake : mapData.lakes) {
                if (h.getHitbox().intersects(lake.getHitbox())) {
                    if (!discoveredDrinks1.contains(lake)) {
                        System.out.println("Herbivore hit a lake!");
                        discoveredDrinks1.add(lake);
                    }

                    if (h.isThirsty()) {
                        h.setDestination(lake.getPosition());
                        h.moveTowards(lake.getPosition(), speed);
                        h.drink(discoveredDrinks1, discoveredRivers);
                    }
                }

            }

        }
        for (Carnivore c : carnivores) {
            boolean isInRiver = false;
            boolean isOnHill = false;
            for (Herbivore h : herbivores) {
                if (c.getHitbox().intersects(h.getHitbox())) {
                    if (!discoveredFood.contains(h)) { // Avoid duplicates
                        discoveredFood.add(h);
                        System.out.println("Carnivore hit a herbivore!");
                    }
                    if (c.isHungry()) {
                        // Azonnal megtámadja
                        List<Herbivore> targetList = new ArrayList<>();
                        targetList.add(h);
                        c.huntherb(targetList);
                    }
                }
            }

            for (Hill hill : mapData.hills) {
                if (c.getHitbox().intersects(hill.getHitbox())) {
                    isOnHill = true;// Avoid duplicates
                }

            }

            // Ha bent van dombban → lassítsuk le
            if (isOnHill) {
                c.setSpeed(c.getSpeed() / 2); //
            } else {
                c.resetSpeed(); // visszaáll az eredeti sebesség
            }

            for (River river : mapData.rivers) {
                if (c.getHitbox().intersects(river.getHitbox())) {
                    if (!discoveredRivers.contains(river)) { // Avoid duplicates
                        System.out.println("Carnivore hit a river!");
                        discoveredRivers.add(river);
                    }

                    if (c.isThirsty()) {
                        c.setDestination(river.getPosition());
                        c.moveTowards(river.getPosition(), speed);
                        c.drink(discoveredDrinks2, discoveredRivers);
                    }
                    isInRiver = true;
                }

            }

            // Ha bent van folyóban → lassítsuk le
            if (isInRiver) {
                c.setSpeed(c.getSpeed() / 2); //
            } else {
                c.resetSpeed(); // visszaáll az eredeti sebesség
            }

            for (Lake lake : mapData.lakes) {
                if (c.getHitbox().intersects(lake.getHitbox())) {
                    if (c.getHitbox().intersects(lake.getHitbox())) {
                        if (!discoveredDrinks2.contains(lake)) {
                            System.out.println("Herbivore hit a lake!");
                            discoveredDrinks2.add(lake);
                        }

                        if (c.isThirsty()) {
                            c.setDestination(lake.getPosition());
                            c.moveTowards(lake.getPosition(), speed);
                            c.drink(discoveredDrinks2, discoveredRivers);
                        }
                    }

                }
            }
        }

    }


    /**
     * Naponta frissíti a játékmenet állapotát (nappal/éjszaka váltás).
     *
     * Minden nap végén növeli a napok és sorozatok számát, ha még él legalább egy növényevő
     * és egy ragadozó. Ha nem, a sorozat újraindul. A napszakot grafikai elem is visszajelzi.
     */
    public void updateDayProgress() {
        tickCounter++;

        if (tickCounter >= currentPhaseDuration / speed) {
            tickCounter = 0;
            isDaylight = !isDaylight;
            toggleDayNight(isDaylight);

            if (isDaylight) {
                currentPhaseDuration = dayDuration;
                dayCount++;
                dayLabel.setText(String.format("Day: %03d", dayCount));

                if (getHerbivoreCount() >= 1 && getCarnivoreCount() >= 1) {
                    streakCount++;
                } else {
                    streakCount = 0;
                }
                streakLabel.setText(String.format("Streak: %03d", streakCount));

            } else {
                currentPhaseDuration = nightDuration;
            }
        }
    }

    /**
     * Visszaadja az aktuálisan élő növényevők számát.
     *
     * @return Az élő növényevők száma.
     */

    public int getHerbivoreCount() {
        return mapData.herbivores.size();
    }

    /**
     * Visszaadja az aktuálisan élő ragadozók számát.
     *
     * @return Az élő ragadozók száma.
     */
    public int getCarnivoreCount() {
        return mapData.carnivores.size();
    }



    /**
     * Ellenőrzi a győzelem vagy vereség feltételeit, és megjelenít egy üzenetet, ha a játék véget ért.
     *
     * - Vereség, ha minden állat elpusztult vagy elfogyott a pénz.
     * - Győzelem, ha a nehézségi szintnek megfelelően elérted a megadott túlélési napok számát.
     */
    public void checkWinCondition() {
        if (mapData.herbivores.isEmpty() && mapData.carnivores.isEmpty()) {
            gameTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "You lost! All herbivores and carnivores are dead.",
                    "Game Over",
                    JOptionPane.ERROR_MESSAGE);

        } else if (money <= 0) {
            gameTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "You lost! You ran out of money.",
                    "Game Over",
                    JOptionPane.ERROR_MESSAGE);

        } else if ("Easy".equals(difficulty) && streakCount >= 10) {
            gameTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "You won! You survived 10 days.",
                    "Victory!",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if ("Medium".equals(difficulty) && streakCount >= 20) {
            gameTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "You won! You survived 20 days.",
                    "Victory!",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if ("Hard".equals(difficulty) && streakCount >= 30) {
            gameTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "You won! You survived 30 days.",
                    "Victory!",
                    JOptionPane.INFORMATION_MESSAGE);

        }

    }



    /**
     * Kiértékeli a játék aktuális állapotát.
     *
     * @return A játék állapota a GameStatus enum szerint (pl. folyamatban, győzelem, vereség).
     */
    public GameStatus evaluateGameStatus() {
        if (mapData.herbivores.isEmpty() && mapData.carnivores.isEmpty()) {
            return GameStatus.LOST_ALL_ANIMALS;
        } else if (money <= 0) {
            return GameStatus.LOST_NO_MONEY;
        } else if ("Easy".equals(difficulty) && streakCount >= 10) {
            return GameStatus.WON_EASY;
        } else if ("Medium".equals(difficulty) && streakCount >= 20) {
            return GameStatus.WON_MEDIUM;
        } else if ("Hard".equals(difficulty) && streakCount >= 30) {
            return GameStatus.WON_HARD;
        } else {
            return GameStatus.ONGOING;
        }
    }


    /**
     * Enum típus a játék állapotának nyomon követésére.
     */
    public enum GameStatus {
        ONGOING,
        LOST_ALL_ANIMALS,
        LOST_NO_MONEY,
        WON_EASY,
        WON_MEDIUM,
        WON_HARD
    }

    /**
     * A jatekpalyan sebesseggel rendelkezo elemeket (pl. őrök, vadászok, dzsippek) gyorsitja/lassitja.
     */
    private void switchSpeed() {
        speed = (speed % 3) + 1;
        speedButton.setText("Speed x" + speed);

        for(Jeep j : jeeps){
            j.setSpeed(speed);
        }
        for(Guard gu : mapData.guards){
            gu.setSpeed(speed);
        }
        for(Hunter hu : mapData.hunters){
            hu.setSpeed(speed);
        }
        // ticksUntilNextDay nem változik, csak a sebességgel osztjuk
    }


    /**
     * A jatekpalya tetejen talalhato toolbar megjelenitese
     */
    public void createToolbar() {
        toolbar = new JToolBar();
        toolbar.setFloatable(false);
        toolbar.setBackground(new Color(45, 45, 45));
        toolbar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));



        ImageIcon manageIcon = loadIcon("src/main/resources/manage.png", 20, 20);
        ImageIcon shopIcon = loadIcon("src/main/resources/shop.png", 20, 20);
        ImageIcon sunIcon = loadIcon("src/main/resources/sun.png", 20, 20);
        ImageIcon moonIcon = loadIcon("src/main/resources/moon.png", 20, 20);

        // Buttons
        manageButton = createButton("Manage", manageIcon, new Color(100, 100, 255));
        manageButton.addActionListener(e -> toggleManageMenu());
        shopButton = createButton("Shop", shopIcon, new Color(180, 100, 100));
        shopButton.addActionListener(e -> toggleShop());

        // Labels
        streakLabel = createLabel("Streak: 0");
        dayLabel = createLabel("Day: 001");
        moneyLabel = createLabel("Money: 0");
        moneyLabel.setText("Money: " + money);

        // Speed button
        speedButton = createButton("Speed x1", null, new Color(255, 165, 0));
        speedButton.addActionListener(e -> switchSpeed());



        // Day/Night indicator
        dayNightLabel = new JLabel();
        dayNightLabel.setOpaque(true);
        dayNightLabel.setBackground(Color.WHITE);


        // Set icons after initialization
        if (isDaylight) {
            dayNightLabel.setIcon(sunIcon);
        } else {
            dayNightLabel.setIcon(moonIcon);
        }

        // Left-side elements
        toolbar.add(manageButton);
        toolbar.addSeparator();
        toolbar.add(shopButton);
        toolbar.addSeparator();
        toolbar.add(speedButton);
        toolbar.addSeparator(new Dimension(100,0));

        // Center elements
        toolbar.add(streakLabel);
        toolbar.addSeparator(new Dimension(50,0));

        // Right-side elements
        toolbar.addSeparator();
        toolbar.addSeparator(new Dimension(70,0));
        toolbar.add(moneyLabel);
        toolbar.addSeparator();
        toolbar.add(dayNightLabel);
        toolbar.addSeparator();
        toolbar.add(dayLabel);
        add(toolbar, BorderLayout.NORTH);
    }


    /**
     * Létrehoz egy testreszabott JButton-t megadott szöveggel, ikonnal és háttérszínnel.
     *
     * @param text a gombon megjelenő szöveg
     * @param icon a gombon megjelenő ikon
     * @param bgColor a gomb háttérszíne
     * @return a formázott JButton példány
     */

    private JButton createButton(String text, ImageIcon icon, Color bgColor) {
        JButton button = new JButton(text, icon);
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        return button;
    }

    /**
     * Létrehoz egy JLabel-t fehér betűszínnel.
     *
     * @param text a címkén megjelenő szöveg
     * @return a formázott JLabel példány
     */

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        return label;
    }

    /**
     * Megnyitja vagy bezárja a bolt panelt.
     * A panelen vásárolható elemek (növények, állatok, járművek stb.) jelennek meg.
     * A panelen kívüli kattintás vagy a "Close" gomb bezárja a panelt.
     */

    private void toggleShop() {
        if (!isActionPanelOpen) {
            isActionPanelOpen = true;
            overlayPanel = new JPanel();
            overlayPanel.setBounds(0, 0, getWidth(), getHeight());
            overlayPanel.setOpaque(false);
            overlayPanel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (!actionPanel.getBounds().contains(e.getPoint())) {
                        toggleShop();
                    }
                }
            });

            actionPanel = new JPanel();
            actionPanel.setLayout(new GridLayout(0, 1, 10, 10));
            actionPanel.setBounds(getWidth() / 2 - 200, getHeight() / 2 - 300, 400, 600);
            actionPanel.setBackground(new Color(255, 255, 255));
            actionPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            JLabel shopLabel = new JLabel("Shop", SwingConstants.CENTER);
            shopLabel.setFont(new Font("Arial", Font.BOLD, 24));
            actionPanel.add(shopLabel, BorderLayout.NORTH);

            addItemToShop(loadIcon("src/main/resources/bush.png", 50, 50), "Bush", Bush.price);
            addItemToShop(loadIcon("src/main/resources/grass.png", 50, 50), "Grass", Grass.price);
            addItemToShop(loadIcon("src/main/resources/tree.png", 50, 50), "Tree", Tree.price);
            addItemToShop(loadIcon("src/main/resources/lake.png", 50, 50), "Lake", Lake.price);
            addItemToShop(loadIcon("src/main/resources/lion.png", 50, 50), "Lion", Lion.price);
            addItemToShop(loadIcon("src/main/resources/leopard.png", 50, 50), "Leopard", Leopard.price);
            addItemToShop(loadIcon("src/main/resources/giraffe.png", 50, 50), "Giraffe", Giraffe.price);
            addItemToShop(loadIcon("src/main/resources/zebra.png", 50, 50), "Zebra", Zebra.price);
            addItemToShop(loadIcon("src/main/resources/guard.png", 50, 50), "Guard", Guard.price);
            addItemToShop(loadIcon("src/main/resources/jeep.png", 50, 50), "Jeep", Jeep.price);
            addItemToShop(loadIcon("src/main/resources/road.jpg", 50, 50), "Road", Road.price);

            JButton closeButton = new JButton("Close");
            closeButton.addActionListener(e -> toggleShop());
            actionPanel.add(closeButton, BorderLayout.SOUTH);

            JLayeredPane layeredPane = getRootPane().getLayeredPane();
            layeredPane.add(overlayPanel, JLayeredPane.DEFAULT_LAYER);
            layeredPane.add(actionPanel, JLayeredPane.POPUP_LAYER);
            layeredPane.revalidate();
            layeredPane.repaint();
        } else {
            isActionPanelOpen = false;
            JLayeredPane layeredPane = getRootPane().getLayeredPane();
            layeredPane.remove(actionPanel);
            layeredPane.remove(overlayPanel);
            layeredPane.revalidate();
            layeredPane.repaint();
        }
    }


    /**
     * Hozzáad egy elemet a bolt panelhez egy ikonnal, névvel és árral.
     * Tartalmaz egy "Buy" gombot, amely vásárláskor meghívja a logikát.
     *
     * @param icon az elem ikonja
     * @param name az elem neve
     * @param price az elem ára
     */

    private void addItemToShop(ImageIcon icon, String name, int price) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        JLabel iconLabel = new JLabel(icon);
        itemPanel.add(iconLabel, BorderLayout.WEST);
        JLabel nameLabel = new JLabel(name, SwingConstants.CENTER);
        itemPanel.add(nameLabel, BorderLayout.CENTER);
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.X_AXIS));
        rightPanel.setAlignmentY(Component.CENTER_ALIGNMENT);
        JLabel priceLabel = new JLabel("$" + price);
        JButton buyButton = new JButton("Buy");
        buyButton.addActionListener(e -> {
            System.out.println("Buying: " + name);
            buyItem(name, icon);
        });
        rightPanel.add(priceLabel);
        rightPanel.add(Box.createHorizontalStrut(10));
        rightPanel.add(buyButton);
        itemPanel.add(rightPanel, BorderLayout.EAST);
        actionPanel.add(itemPanel);
    }


    /**
     * Megnyitja vagy bezárja a kezelőmenüt, ahol beállításokat lehet módosítani
     * (pl. belépődíj), valamint az állatokat lehet eladni vagy követőt vásárolni.
     * A panel kívüli kattintás vagy a "Close" gomb bezárja a menüt.
     */

    private void toggleManageMenu() {
        if (!isActionPanelOpen) {
            isActionPanelOpen = true;
            overlayPanel = new JPanel();
            overlayPanel.setBounds(0, 0, getWidth(), getHeight());
            overlayPanel.setOpaque(false);
            overlayPanel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (!actionPanel.getBounds().contains(e.getPoint())) {
                        toggleManageMenu();
                    }
                }
            });

            actionPanel = new JPanel();
            actionPanel.setLayout(new BoxLayout(actionPanel, BoxLayout.Y_AXIS));
            actionPanel.setBounds(getWidth() / 2 - 250, getHeight() / 2 - 300, 500, 600);
            actionPanel.setBackground(Color.WHITE);
            actionPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

            JLabel manageLabel = new JLabel("Manage", SwingConstants.CENTER);
            manageLabel.setFont(new Font("Arial", Font.BOLD, 24));
            manageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            actionPanel.add(Box.createVerticalStrut(20));
            actionPanel.add(manageLabel);
            actionPanel.add(Box.createVerticalStrut(20));

            JPanel centerPanel = new JPanel();
            centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
            centerPanel.setOpaque(false);
            addEntryPriceChanger(centerPanel);
            JLabel animalsLabel = new JLabel("Animals", SwingConstants.CENTER);
            animalsLabel.setFont(new Font("Arial", Font.BOLD, 16));
            animalsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            centerPanel.add(Box.createVerticalStrut(20));
            centerPanel.add(animalsLabel);
            centerPanel.add(Box.createVerticalStrut(20));
            for (Animal a : mapData.herbivores) {
                if (a instanceof Giraffe) {
                    addAnimalToMenu(centerPanel, Giraffe.sellPrice, a);
                } else if (a instanceof Zebra) {
                    addAnimalToMenu(centerPanel, Zebra.sellPrice, a);
                }
            }
            for (Animal a : mapData.carnivores) {
                if (a instanceof Lion) {
                    addAnimalToMenu(centerPanel, Lion.sellPrice, a);
                } else if (a instanceof Leopard) {
                    addAnimalToMenu(centerPanel, Leopard.sellPrice, a);
                }
            }
            JScrollPane scrollPane = new JScrollPane(centerPanel);
            scrollPane.setBorder(null);
            scrollPane.setPreferredSize(new Dimension(380, 400)); // or whatever height fits your layout
            scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
            actionPanel.add(scrollPane);

            actionPanel.add(Box.createVerticalGlue());

            JButton closeButton = new JButton("Close");
            closeButton.addActionListener(e -> toggleManageMenu());
            closeButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
            closeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            actionPanel.add(closeButton);
            actionPanel.add(Box.createVerticalStrut(10));

            JLayeredPane layeredPane = getRootPane().getLayeredPane();
            layeredPane.add(overlayPanel, JLayeredPane.DEFAULT_LAYER);
            layeredPane.add(actionPanel, JLayeredPane.POPUP_LAYER);
            layeredPane.revalidate();
            layeredPane.repaint();
        } else {
            isActionPanelOpen = false;
            JLayeredPane layeredPane = getRootPane().getLayeredPane();
            layeredPane.remove(actionPanel);
            layeredPane.remove(overlayPanel);
            layeredPane.revalidate();
            layeredPane.repaint();
        }
    }

    /**
     * Hozzáad egy belépődíj-módosító mezőt a megadott panelhez.
     * Csak számokat enged meg, és minimum 10-es értéket fogad el.
     *
     * @param parent az a panel, amelyhez a mező hozzáadódik
     */

    private void addEntryPriceChanger(JPanel parent) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        Dimension fixedSize = new Dimension(350, 40);
        itemPanel.setMaximumSize(fixedSize);
        itemPanel.setPreferredSize(fixedSize);
        itemPanel.setMinimumSize(fixedSize);

        JLabel ticketPriceLabel = new JLabel("Entry ticket price:");
        itemPanel.add(ticketPriceLabel, BorderLayout.WEST);
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.X_AXIS));
        //rightPanel.setAlignmentY(Component.CENTER_ALIGNMENT);

        JTextField textField = new JTextField(String.valueOf(entryPrice), 10);
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DigitFilter());

        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                try {
                    int input = Integer.parseInt(textField.getText());
                    if (input >= 10) {
                        entryPrice = input;
                        System.out.println("Entry ticket price changed to $" + entryPrice);
                    } else {
                        JOptionPane.showMessageDialog(actionPanel, "Value must be at least 10.");
                        textField.setText(String.valueOf(entryPrice));
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(actionPanel, "Invalid number.");
                    textField.setText(String.valueOf(entryPrice));
                }
            }
        });

        rightPanel.add(textField);
        itemPanel.add(rightPanel, BorderLayout.EAST);
        parent.add(itemPanel);
        actionPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!(e.getSource() instanceof JTextField)) {
                    Component clicked = SwingUtilities.getDeepestComponentAt(actionPanel, e.getX(), e.getY());
                    if (clicked != textField) {
                        actionPanel.requestFocusInWindow();
                    }
                }
            }
        });
    }


    /**
     * Hozzáad egy állatot a kezelőmenübe, amelyet el lehet adni, vagy
     * ha még nincs, követőt lehet rá vásárolni.
     *
     * @param parent a panel, amelyhez az állat hozzáadódik
     * @param price az állat eladási ára
     * @param animal az adott állat példány
     */

    private void addAnimalToMenu(JPanel parent, int price, Animal animal) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel iconLabel = new JLabel(animal.getImage());
        itemPanel.add(iconLabel, BorderLayout.WEST);
        JLabel nameLabel = new JLabel(animal.getName(), SwingConstants.CENTER);
        itemPanel.add(nameLabel, BorderLayout.CENTER);
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.X_AXIS));
        rightPanel.setAlignmentY(Component.CENTER_ALIGNMENT);
        JButton sellButton = new JButton("Sell for $" + price);
        sellButton.addActionListener(e -> {
            System.out.println("Sold: " + animal.getName());
            if (animal instanceof Giraffe) {
                mapData.herbivores.remove(animal);
                allAnimals.remove(animal);
                herbivores.remove(animal);
                money += Giraffe.sellPrice;
            } else if (animal instanceof Lion) {
                mapData.carnivores.remove(animal);
                allAnimals.remove(animal);
                carnivores.remove(animal);
                money += Lion.sellPrice;
            } else if (animal instanceof Zebra) {
                mapData.herbivores.remove(animal);
                allAnimals.remove(animal);
                herbivores.remove(animal);
                money += Zebra.sellPrice;
            } else if (animal instanceof Leopard) {
                mapData.carnivores.remove(animal);
                allAnimals.remove(animal);
                carnivores.remove(animal);
                money += Leopard.sellPrice;
            }
            parent.remove(itemPanel);
        });
        rightPanel.add(sellButton);
        rightPanel.add(Box.createHorizontalStrut(10));
        if (animal.hasLocator()) {
            JLabel hasLocatorLabel = new JLabel("Locator ✓");
            rightPanel.add(hasLocatorLabel);
        } else {
            JButton buyLocatorButton = new JButton("Buy locator for $" + locatorPrice);
            buyLocatorButton.addActionListener(e -> {
                if (money < locatorPrice) {
                    JOptionPane.showMessageDialog(parent,
                            "Not enough money to buy this item.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else {
                    System.out.println("Bought locator for: " + animal.getName());
                    animal.buyLocatorForAnimal();
                    money -= locatorPrice;
                    rightPanel.remove(buyLocatorButton);
                    JLabel hasLocatorLabel = new JLabel("Locator ✓");
                    rightPanel.add(hasLocatorLabel);
                }
            });
            rightPanel.add(buyLocatorButton);
        }
        itemPanel.add(rightPanel, BorderLayout.EAST);
        parent.add(itemPanel);
    }

    /**
     * Nappali vagy éjszakai módra váltja az időt, és ennek megfelelően módosítja az ikon megjelenését.
     *
     * @param isDay igaz, ha nappali módot szeretnénk, hamis éjszaka esetén
     */

    private void toggleDayNight(boolean isDay) {
        if (isDay) {
            dayNightLabel.setIcon(loadIcon("src/main/resources/sun.png", 20, 20));
        } else {
            dayNightLabel.setIcon(loadIcon("src/main/resources/moon.png", 20, 20));
        }

    }

    /**
     * Betölt egy képet az adott elérési útvonalról, és a megadott méretre skálázza.
     *
     * @param path a kép relatív elérési útvonala
     * @param width a kívánt szélesség
     * @param height a kívánt magasság
     * @return a méretezett ImageIcon példány
     */

    private ImageIcon loadIcon(String path, int width, int height) {
        try {
            URL location = getClass().getResource(path.startsWith("/") ? path : "/" + path);
            if (location == null) {
                System.err.println("Icon not found at path: " + path);
                return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB)); // fallback: üres kép
            }
            ImageIcon icon = new ImageIcon(location);
            Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
        } catch (Exception e) {
            e.printStackTrace();
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB)); // fallback: üres kép
        }
    }




    /**
     * Kirajzolja a teljes pályát, az objektumokat és az állatokat nappali vagy éjszakai módban.
     * Éjszakai módban csak a lokátorral rendelkező állatok látszanak.
     *
     * @param g a rajzolásra használt Graphics objektum
     */

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (isDaylight) {
            g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
            mapData.draw(g);

            // Draw animals
            for (Herbivore h : mapData.herbivores) {
                h.draw(g);
            }
            for (Carnivore c : mapData.carnivores) {
                c.draw(g);
            }

            // Draw hitboxes for other objects (e.g., trees, bushes)
            for (Tree tree : mapData.trees) {
                Rectangle hitbox = tree.getHitbox();
                g.setColor(Color.BLUE); // Set hitbox color
                g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
            }

            for (Bush bush : mapData.bushes) {
                Rectangle hitbox = bush.getHitbox();
                g.setColor(Color.GREEN); // Set hitbox color
                g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
            }
            for (Lake lake : mapData.lakes) {
                Rectangle hitbox = lake.getHitbox();
                g.setColor(Color.GREEN); // Set hitbox color
                g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
            }
            for (River river : mapData.rivers) {
                Rectangle hitbox = river.getHitbox();
                g.setColor(Color.GREEN); // Set hitbox color
                g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
            }
            for (Grass grass : mapData.grassyAreas) {
                Rectangle hitbox = grass.getHitbox();
                g.setColor(Color.GREEN); // Set hitbox color
                g.drawRect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
            }
            for (Hill hill : mapData.hills) {
                hill.draw((Graphics2D) g);
            }
        } else {
            drawNightVision(g); // ebben benne van a háttér és a pálya
            // Nem rajzoljuk ki az állatokat, kivéve a lokátorral rendelkezőket
        }
        for (Jeep j : jeeps) {
            j.draw((Graphics2D) g);
        }
        for(Guard gu : mapData.guards){
            gu.draw((Graphics2D) g);
        }
        if (isPlacing && ghostImage != null && ghostPosition != null) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
            g2d.drawImage(ghostImage, ghostPosition.x - ghostImage.getWidth(null) / 2,
                    ghostPosition.y - ghostImage.getHeight(null) / 2, null);
            g2d.dispose();
        }
    }


    /**
     * Éjszakai nézet megjelenítése: csak a megvilágított objektumok látszanak.
     * Először kirajzolja a teljes pályát, majd ráhelyez egy sötét maszkot világos körökkel,
     * végül megjeleníti a lokátorral rendelkező állatokat.
     *
     * @param g a rajzolásra használt Graphics objektum
     */

    private void drawNightVision(Graphics g) {
        int w = getWidth();
        int h = getHeight();

        // 1. Kirajzoljuk az egész pályát egy image-be
        BufferedImage mapBuffer = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D gMap = mapBuffer.createGraphics();
        gMap.drawImage(background, 0, 0, w, h, this);
        mapData.draw(gMap);
        gMap.dispose();

        // 2. Létrehozzuk a maszkot: fekete réteg + világos foltok
        BufferedImage mask = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D gMask = mask.createGraphics();
        gMask.setColor(new Color(0, 0, 0, 255));
        gMask.fillRect(0, 0, w, h);

        // Világos (látható) körök
        gMask.setComposite(AlphaComposite.Clear);  // Eltávolítjuk ebből a részből a sötétet

        for (Bush bush : mapData.bushes) {
            drawLightCircle(gMask, bush.getX(), bush.getY(), 80);
        }
        for (Tree tree : mapData.trees) {
            drawLightCircle(gMask, tree.getX(), tree.getY(), 80);
        }
        for (Grass grass : mapData.grassyAreas) {
            drawLightCircle(gMask, grass.getX(), grass.getY(), 80);
        }
        for (Lake lake : mapData.lakes) {
            drawLightCircle(gMask, lake.getX(), lake.getY(), 80);
        }
        for (Road road : mapData.road) {
            drawLightCircle(gMask, road.getX(), road.getY(), 100);
        }
        for (River river : mapData.rivers) {
            drawLightCircle(gMask, river.getX(), river.getY(), 100);
        }
        for (Hill hill : mapData.hills) {
            drawLightCircle(gMask, hill.getX(), hill.getY(), 100);
        }

        gMask.dispose();

        //3. Maszkolás: csak a világos részt rajzoljuk ki
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(mapBuffer, 0, 0, null); // teljes pálya
        g2d.drawImage(mask, 0, 0, null);     // rá a sötét maszkkal
        for (Herbivore he : mapData.herbivores) {
            if (!he.isDead() && he.hasLocator()) {
                he.draw(g);
            }
        }
        for (Carnivore c : mapData.carnivores) {
            if (!c.isDead() && c.hasLocator()) {
                c.draw(g);
            }
        }
    }

    /**
     * Egy világos kör rajzolása a megadott koordináták köré.
     * A világos körök az éjszakai nézeten belül láthatóvá teszik az objektumokat.
     *
     * @param g2d a rajzoláshoz használt Graphics2D objektum
     * @param x a kör középpontjának X koordinátája
     * @param y a kör középpontjának Y koordinátája
     * @param radius a kör sugara
     */

    private void drawLightCircle(Graphics2D g2d, int x, int y, int radius) {
        g2d.fillOval(x - radius / 2, y - radius / 2, radius, radius);
    }


    /**
     * Megpróbál megvásárolni egy elemet a boltban. Ellenőrzi, hogy van-e elég pénz,
     * és elindítja a vásárlási folyamatot.
     *
     * @param type az elem típusa (pl. Bush, Lion, Jeep)
     * @param icon az elemhez tartozó ikon
     */

    public void buyItem(String type, ImageIcon icon) {
        int price = 1;
        if (type.equals("Bush") || type.equals("Grass") || type.equals("Tree") || type.equals("Lake") || type.equals("Road")) {
            price = getPriceByClassName("src.map." + type);
        } else {
            price = getPriceByClassName("src.moveables." + type);
        }

        if (money < price) {
            JOptionPane.showMessageDialog(this,
                    "Not enough money to buy this item.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        toggleShop();
        startPlacingItem(type, icon.getImage());
        money -= price;
    }

    /**
     * Előkészíti az elem elhelyezését a pályán: elindítja a "szellemkép" megjelenítését,
     * és beállítja a megfelelő kurzort.
     *
     * @param type az elhelyezendő elem típusa
     * @param image az elem képe
     */

    public void startPlacingItem(String type, Image image) {
        if (type.equals("Jeep")) {
            jeeps.add(new Jeep(mapData.entrance.x, mapData.entrance.y, Direction.RIGHT, Direction.DOWN, 1, (int) (1.5 * cellSize), (int) (1.5 * cellSize), new ImageIcon("src/main/resources/jeep.png").getImage()));
            return;
        }
        ghostType = type;
        ghostImage = image;
        isPlacing = true;
        setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
    }

    /**
     * Elhelyez egy objektumot a pályán a megadott koordinátákon.
     * A ghostType értéke alapján dönti el, milyen típusú objektum kerüljön elhelyezésre.
     *
     * @param point a kattintás helye, ahová az objektum kerül
     */


    private void placeItemAt(Point point) {
        switch (ghostType) {
            case "Bush":
                mapData.bushes.add(new Bush(point.x, point.y, cellSize, cellSize));
                break;
            case "Tree":
                mapData.trees.add(new Tree(point.x, point.y, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                break;
            case "Grass":
                mapData.grassyAreas.add(new Grass(point.x, point.y, 3 * cellSize, 2 * cellSize));
                break;
            case "Road":
                mapData.road.add(new Road(point.x, point.y, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                break;
            case "Giraffe":
                Giraffe g = new Giraffe(point.x, point.y, 2 * cellSize, 2 * cellSize);
                mapData.herbivores.add(g);
                herbivores.add(g);
                allAnimals.add(g);
                break;
            case "Zebra":
                Zebra z = new Zebra(point.x, point.y, 2 * cellSize, 2 * cellSize);
                mapData.herbivores.add(z);
                herbivores.add(z);
                allAnimals.add(z);
                break;
            case "Lion":
                Lion l = new Lion(point.x, point.y, (int) (1.5 * cellSize), (int) (1.5 * cellSize));
                mapData.carnivores.add(l);
                carnivores.add(l);
                allAnimals.add(l);
                break;
            case "Leopard":
                Leopard le = new Leopard(point.x, point.y, (int) (1.5 * cellSize), (int) (1.5 * cellSize));
                mapData.carnivores.add(le);
                carnivores.add(le);
                allAnimals.add(le);
                break;
            case "Lake":
                mapData.lakes.add(new Lake(point.x, point.y, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                break;
            case "Guard":
                createAndAddGuard(point.x, point.y);
                break;
        }
        System.out.println("Placed item at: " + point);
        setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }


    /**
     * Létrehoz egy Guard objektumot a megadott koordinátákon, és hozzáadja a pályához.
     * Ha vannak ragadozók, az egyik célpontként beállításra kerül.
     *
     * @param x az őr X koordinátája
     * @param y az őr Y koordinátája
     */

    private void createAndAddGuard(int x, int y) {
        Random random = new Random();
        Carnivore initialTarget = null;
        if(mapData.carnivores!= null)
        {
            if(!mapData.carnivores.isEmpty())
            {
                initialTarget = mapData.carnivores.get(random.nextInt(carnivores.size()));
                initialTarget.setShowHitbox(true);
            }
        }

        Guard guard = new Guard(
                x,
                y,
                Direction.RIGHT,
                Direction.DOWN,
                2, 50, 50,
                loadIcon("/src/main/resources/guard.png", 50, 50).getImage(),
                initialTarget!= null ? initialTarget : null
        );
        mapData.guards.add(guard);
    }


    /**
     * Egy felugró ablakot hoz létre, ahol kiválasztható, hogy az őr milyen célpontot kövessen (állat vagy vadász).
     * A célpontok hitboxai láthatóvá válnak.
     *
     * @param guard az őr, akinek célpontját szeretnénk módosítani
     * @return a létrehozott JDialog ablak
     */

    private JDialog createAnimalTargetPopup(Guard guard) {

        if(guard.getHuntedAnimal() != null)guard.getHuntedAnimal().setShowHitbox(true);
        if(guard.getHuntedHunter() != null){guard.getHuntedHunter().setShowHitbox(true); guard.getHuntedHunter().setInvisible(false);}

        JDialog popup = new JDialog((Frame) null, "Choose Target", true);
        popup.setLayout(new FlowLayout());
        popup.setSize(300, 120);
        popup.setLocationRelativeTo(null);

        JLabel infoLabel = new JLabel("Choose target:");

        JRadioButton animalRadio = new JRadioButton("Animal", true);
        JRadioButton hunterRadio = new JRadioButton("Hunter");

        ButtonGroup group = new ButtonGroup();
        group.add(animalRadio);
        group.add(hunterRadio);

        JButton switchButton = new JButton("Switch target");
        JButton closeButton = new JButton("Close");

        popup.add(infoLabel);
        popup.add(animalRadio);
        popup.add(hunterRadio);
        popup.add(switchButton);
        popup.add(closeButton);

        setupSwitchListener(switchButton, guard, animalRadio, hunterRadio);
        setupCloseButtonListener(closeButton, popup, guard);

        return popup;
    }


    /**
     * Beállítja a kapcsoló gomb hallgatóját, amely váltja a célt, amit a Guard üldöz.
     * Ha az állat vagy vadász rádiógombok valamelyike ki van választva, véletlenszerűen választ új célpontot
     * az állatok vagy vadászok listájából, és frissíti a célt a Guard számára.
     *
     * @param switchButton A gomb, amelynek a lenyomásával váltani lehet a célt.
     * @param guard A Guard objektum, amely az aktuális üldözőt reprezentálja.
     * @param animalRadio Az állat választó rádiógomb.
     * @param hunterRadio A vadász választó rádiógomb.
     */
    private void setupSwitchListener(JButton switchButton, Guard guard, JRadioButton animalRadio, JRadioButton hunterRadio) {
        Random random = new Random();

        switchButton.addActionListener(event -> {
            System.out.println("Target switched!");

            // Avoid NullPointerException by checking if current target exists
            Carnivore currentTarget = guard.getHuntedAnimal();
            if (currentTarget != null) {
                currentTarget.setShowHitbox(false);
            }
            Hunter currentHunter = guard.getHuntedHunter();
            if (currentHunter != null) {
                currentHunter.setShowHitbox(false);
                currentHunter.setInvisible(true);
            }

            if (!mapData.carnivores.isEmpty() && animalRadio.isSelected()) {
                Carnivore newTarget = mapData.carnivores.get(random.nextInt(mapData.carnivores.size()));
                newTarget.setShowHitbox(true);
                guard.setHuntedHunter(null);
                guard.setHuntedAnimal(newTarget);
            }
            if (!mapData.hunters.isEmpty() && hunterRadio.isSelected()) {
                Hunter newTarget = mapData.hunters.get(random.nextInt(mapData.hunters.size()));
                newTarget.setShowHitbox(true);
                newTarget.setInvisible(false);
                guard.setHuntedAnimal(null);
                guard.setHuntedHunter(newTarget);
            }
        });
    }



    /**
     * Beállítja a bezáró gomb hallgatóját, amely bezárja a felugró ablakot és eltünteti az összes állat hitboxát.
     *
     * @param closeButton A gomb, amely a felugró ablakot bezárja.
     * @param popup A felugró ablak, amelyet be kell zárni.
     * @param guard A Guard objektum, amely az állatok üldözéséért felelős.
     */
    private void setupCloseButtonListener(JButton closeButton, JDialog popup, Guard guard) {
        closeButton.addActionListener(event -> {
            for (Carnivore c : mapData.carnivores) {
                c.setShowHitbox(false);
            }
            popup.dispose();
        });
    }


    /**
     * Frissíti a dzsipek mozgását, ha azok léteznek.
     * Minden dzsip végrehajtja a mozgást.
     */
    private void moveJeep() {
        if (jeeps == null) {
            return;
        }

        for (Jeep j : jeeps) {
            j.move();
        }
    }

    /**
     * Frissíti a Guard objektumok mozgását és akcióit.
     * A Guard üldözheti az állatokat vagy vadászokat, és ha közel kerül egy vadászhoz, tüzelni is képes.
     */
    public void moveGuard() {
        int thresholdDistance = 300;
        int shootDistance = 40;

        if (mapData.guards == null) {
            return;
        }

        for (Guard guard : mapData.guards) {
            if (guard.getHuntedAnimal() != null) {
                guard.move();
            }
            if(guard.getHuntedHunter() != null)
            {
                guard.move();
            }

            for (Hunter hunter : new ArrayList<>(mapData.hunters)) { // avoid ConcurrentModificationException
                double dx = guard.getX() - hunter.getX();
                double dy = guard.getY() - hunter.getY();
                double distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= thresholdDistance) {
                    hunter.setInvisible(false);
                }

                guard.shootIfClose(hunter, shootDistance); // delegate to Guard
            }
        }
    }


    /**
     * Ellenőrzi, hogy a Guard objektumra kattintottak-e az egérrel.
     *
     * @param guard A Guard objektum, amelyet ellenőrizni kell.
     * @param mouseX Az egér aktuális X koordinátája.
     * @param mouseY Az egér aktuális Y koordinátája.
     * @return Igaz, ha a Guard objektumon történt kattintás, egyébként hamis.
     */
    private boolean isClicked(Guard guard, int mouseX, int mouseY) {
        Rectangle guardBounds = new Rectangle(guard.getX(), guard.getY(), guard.getWidth(), guard.getHeight());
        return guardBounds.contains(mouseX, mouseY);
    }


    /**
     * Kezeli a Guard objektumra történő kattintást, és megjeleníti a célpont választó felugró ablakot.
     *
     * @param guard A Guard objektum, amelyre kattintottak.
     */
    private void handleGuardClick(Guard guard) {
        System.out.println("Guard clicked!");

        JDialog popup = createAnimalTargetPopup(guard);
        popup.setVisible(true);
    }



    /**
     * Frissíti a vadászok mozgását.
     * Minden vadász végrehajtja a mozgást.
     */
    public void moveHunter(){
        for (Hunter hunter : mapData.hunters) {
            hunter.move();
        }
    }



    /**
     * Visszaadja a megadott osztály neve alapján az osztályhoz tartozó "price" mező értékét.
     *
     * @param className Az osztály neve, amelyhez a "price" mezőt keresni kell.
     * @return Az osztályhoz tartozó "price" mező értéke.
     * @throws RuntimeException Ha hiba történik az osztály vagy mező betöltése közben.
     */
    public int getPriceByClassName(String className) {
        try {
            Class<?> clazz = Class.forName(className);
            Field priceField = clazz.getDeclaredField("price");
            return priceField.getInt(null);
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found");
            throw new RuntimeException(e);
        } catch (NoSuchFieldException e) {
            System.out.println("Field not found");
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            System.out.println("Illegal Access");
            throw new RuntimeException(e);
        }
    }
}