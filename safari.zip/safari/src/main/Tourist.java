package src.main;

import java.util.Random;

public class Tourist {
    private static int idGen = 0;
    private final Random rand = new Random();
    private int touristId = ++idGen;
    private int minSpecies = rand.nextInt(1, 3);
    private int minAnimals = rand.nextInt(1, 7);
    private int maxEntryPrice = rand.nextInt(100, 501);
    private int money = rand.nextInt(100, 4001);

    public Tourist() {}
}
