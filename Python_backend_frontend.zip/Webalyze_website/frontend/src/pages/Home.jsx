import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Welcome to the Webalyze project!</h1>
      <Link to="/check">
        <button>Go to Domain Checker</button>
      </Link>
    </div>
  );
};

export default Home;
