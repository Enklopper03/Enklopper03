package src.moveables;

import javax.swing.*;
import java.awt.*;


/**
 * A Zebra osztály a zebrákat reprezentálja a térképen.
 * A zebra egy növényevő állat, amely egy adott helyet foglal el a térképen.
 * A zebra képe a "zebra.png" fájlból töltődik be.
 */
public class Zebra extends Herbivore {
    private static int idGen = 0;
    public static final int price = 250;
    public static final int sellPrice = 220;


    /**
     * Konstruktor, amely inicializálja a zebra pozícióját, méretét és képét.
     *
     * @param x      A zebra vízszintes koordinátája.
     * @param y      A zebra függőleges koordinátája.
     * @param width  A zebra szélessége.
     * @param height A zebra magassága.
     */
    public Zebra(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/zebra.png").getImage(), "Zebra #" + (++idGen));
    }
}
