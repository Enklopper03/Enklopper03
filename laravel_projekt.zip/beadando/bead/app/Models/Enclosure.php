<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;



class Enclosure extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'limit', 'feeding_at',
    ];

    // protected $casts = [
    //     'feeding_at' => 'datetime',
    // ];

    public function users()
    {
        return $this->belongsToMany(User::class);
    }

    public function animals()
    {
        return $this->hasMany(Animal::class);
    }

    public function animalsCount()
    {
        return $this->animals()->count(); // Az állatok számának lekérdezése
    }

}
