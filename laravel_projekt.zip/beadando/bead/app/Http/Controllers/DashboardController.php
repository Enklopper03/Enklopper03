<?php

namespace App\Http\Controllers;

use App\Models\Enclosure;
use App\Models\Animal;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        // Admin jogkör esetén az összes kifutó
        if ($user->admin) {
            // Az adminnak az összes kifutó megjelenítése
            $enclosuresQuery = Enclosure::with(['animals'])->withCount('animals')->orderBy('name');

        } else {
            // A nem-admin felhasználónak csak a saját kifutói
            $enclosuresQuery = $user->enclosures()->with(['animals'])->withCount('animals')->orderBy('name');
        }
        // 5 rekordos oldalazás
        $enclosures = $enclosuresQuery->paginate(5);


        $currentTime = Carbon::now();
        $feedingTimes = [];

        foreach ($enclosures as $enclosure) {
            $feedingTime = Carbon::createFromFormat('H:i:s', $enclosure->feeding_at);

            if ($feedingTime->greaterThan($currentTime)) {
                $feedingTimes[] = [
                    'enclosure' => $enclosure->name,
                    'feeding_at' => $feedingTime,
                ];
            }
        }




        // Idő szerint rendezve
        usort($feedingTimes, function ($a, $b) {
            return $a['feeding_at']->lt($b['feeding_at']) ? -1 : 1;
        });

        return view('dashboard', [
            'enclosureCount' => Enclosure::count(),
            'animalCount' => Animal::count(),
            'feedingTimes' => $feedingTimes,
            'user' => $user,
            'enclosures' => $enclosures,
        ]);
    }
}
