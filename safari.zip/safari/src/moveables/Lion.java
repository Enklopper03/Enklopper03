package src.moveables;

import javax.swing.*;


/**
 * A Lion osztály a oroszlánt reprezentálja a térképen.
 * Az oroszlán egy ragadozó állat, amely egy adott helyet foglal el a térképen.
 * Az oroszlán képe a "lion.png" fájlból töltődik be.
 */
public class Lion extends Carnivore {
    private static int idGen = 0;
    public static final int price = 300;
    public static final int sellPrice = 270;


    /**
     * Konstruktor, amely inicializálja az oroszlán pozícióját, méretét és képét.
     *
     * @param x      A oroszlán vízszintes koordinátája.
     * @param y      A oroszlán függőleges koordinátája.
     * @param width  A oroszlán szélessége.
     * @param height A oroszlán magassága.
     */
    public Lion(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/lion.png").getImage(), "Lion #" + (++idGen));
    }
}
