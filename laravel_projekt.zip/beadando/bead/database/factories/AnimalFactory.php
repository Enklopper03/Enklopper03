<?php

namespace Database\Factories;

use App\Models\Animal;
use App\Models\Enclosure;
use Illuminate\Database\Eloquent\Factories\Factory;

class AnimalFactory extends Factory
{
    protected $model = Animal::class;

    public function definition()
    {
        return [
            'name' => $this->faker->name,
            'species' => $this->faker->word,
            'is_predator' => $this->faker->boolean,
            'born_at' => $this->faker->dateTimeThisCentury,
            'image' => $this->faker->imageUrl,
            'enclosure_id' => Enclosure::factory(), // A random enclosure-id létrehozása
        ];
    }
}
