<template>
    <div>
        <h3 class="m-3">Hamarosan...</h3>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>