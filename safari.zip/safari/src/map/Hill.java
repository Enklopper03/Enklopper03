package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Hill osztály a dombot reprezentálja a térképen.
 * A domb egy olyan akadály, amely egy adott helyet foglal el a térképen.
 * A domb képe a "hill.png" fájlból töltődik be.
 */
public class Hill extends Obstacle {
    public Hill(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/hill.png").getImage());
    }

}
