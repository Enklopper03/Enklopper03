package src.moveables;

import java.awt.*;


/**
 * A ragadozó osztály, amely az állatok hierarchiájában az Animal osztályból származik.
 * A ragadozó típusú állatok a növényevő állatokat vadászhatják és elfogyaszthatják.
 *
 * A Carnivore osztály az Animal osztályt örökli, és a ragadozók specifikus viselkedését valósítja meg.
 */
public class Carnivore extends Animal {


    /**
     * Konstruktor a Carnivore (ragadozó) objektum létrehozásához.
     *
     * @param x az állat kezdő X koordinátája
     * @param y az állat kezdő Y koordinátája
     * @param width az állat szélessége
     * @param height az állat magassága
     * @param image az állat képe, amelyet megjelenítünk
     * @param name az állat neve
     */
    public Carnivore(int x, int y, int width, int height, Image image, String name) {
        super(x, y, width, height, image, name);
    }

    @Override
    public boolean isDead() {
        return getHealth() <= 0;
    }

}
