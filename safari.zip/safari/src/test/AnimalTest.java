package src.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.map.*;

import src.moveables.Carnivore;



import src.moveables.Animal;
import src.moveables.Herbivore;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;

public class AnimalTest {

    private Animal animal;

    // Dummy Animal class for testing
    class TestAnimal extends Animal {
        public TestAnimal(int x, int y, int width, int height, Image image) {
            super(x, y, width, height, image, "Animal");
        }
    }

    @BeforeEach
    void setUp() {
        animal = new TestAnimal(100, 100, 50, 50, new ImageIcon().getImage());
    }

    @Test
    void testIsHungryAndIsFull() {
        assertTrue(animal.isHungry(), "Animal should be hungry initially");
        assertFalse(animal.isFull(), "Animal should not be full initially");
    }



    @Test
    void testAgeUpIncreasesAgeAndHunger() throws InterruptedException {
        Thread.sleep(31_000); // várunk kicsit, hogy ageUp megtörténjen

        int prevAge = animal.getAge();
        animal.ageUp();

        assertEquals(prevAge + 1, animal.getAge(), "Age should increase after ageUp");
        assertTrue(animal.getHungerLevel() >= 65, "Hunger should increase after ageUp");
    }

    @Test
    void testEatReducesHunger() {
        List<Tree> trees = new ArrayList<>();
        trees.add(new Tree(animal.getX(), animal.getY(), 50, 50));

        int prevHunger = animal.getHungerLevel();
        animal.eat(trees, new ArrayList<>(), new ArrayList<>());

        assertTrue(animal.getHungerLevel() < prevHunger, "Hunger should reduce after eating");
    }

    @Test
    void testDrinkReducesThirst() {
        List<Lake> lakes = new ArrayList<>();
        lakes.add(new Lake(animal.getX(), animal.getY(), 50, 50));

        int prevThirst = animal.getThirstLevel();
        animal.drink(lakes, new ArrayList<>());

        assertTrue(animal.getThirstLevel() < prevThirst, "Thirst should reduce after drinking");
    }

    @Test
    void testRestOnlyWhenFull() {
        // Állat "jóllakott"
        animal.decreaseHealth(-30); // extra HP
        animal.eat(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); // legyen full
        animal.rest();
        // Mivel nem evett ténylegesen, nem indul el automatikusan a pihenés, így csak ellenőrizzük, hogy a metódus nem dob hibát
    }

    @Test
    void testSpeedReducesOnHillAndRiver() {
        // 1. Állítsuk be, hogy az állat eredeti sebessége 2
        int originalSpeed = animal.getSpeed();
        assertEquals(2, originalSpeed, "Default speed should be 2");

        // 2. Szimuláljunk egy Hill-t, ami metszi az állat hitboxát
        Hill fakeHill = new Hill(animal.getX(), animal.getY(), 50, 50);
        assertTrue(animal.getHitbox().intersects(fakeHill.getHitbox()), "Animal should intersect with hill");

        // 3. Lassítsuk le kézzel, ahogy a GameEngine-ben történne
        animal.setSpeed(animal.getSpeed() / 2);
        assertEquals(1, animal.getSpeed(), "Speed should be halved when on a hill");

        // 4. Reseteljük a sebességet
        animal.resetSpeed();
        assertEquals(2, animal.getSpeed(), "Speed should reset back to default");

        // 5. Szimuláljunk egy River-t is
        River fakeRiver = new River(animal.getX(), animal.getY(), 50, 50);
        assertTrue(animal.getHitbox().intersects(fakeRiver.getHitbox()), "Animal should intersect with river");

        animal.setSpeed(animal.getSpeed() / 2);
        assertEquals(1, animal.getSpeed(), "Speed should be halved when in a river");

        animal.resetSpeed();
        assertEquals(2, animal.getSpeed(), "Speed should reset back to default again");
    }

}
