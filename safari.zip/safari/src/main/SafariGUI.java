package src.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;


/**
 * A Safari Tycoon játék fő grafikus felületét megjelenítő osztály.
 * Az osztály felelős a kezdőképernyő megjelenítéséért, amely tartalmazza
 * a játék indításához szükséges gombokat, valamint a nehézségi szint választását.
 */
public class SafariGUI extends JPanel {
    private final Image background;
    private String selectedDifficulty = "Medium";
    private JFrame mainFrame;



    /**
     * Konstruktor, amely beállítja a játék főablakát és a grafikai elemeket.
     * A háttérkép betöltésre kerül, a gombok pedig elhelyezésre kerülnek a képernyőn.
     *
     * @throws IOException Ha nem sikerül betölteni a háttérképet.
     */
    public SafariGUI() throws IOException {
        mainFrame = new JFrame("Safari Tycoon");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(800, 800);
        mainFrame.setResizable(false);
        mainFrame.setLocationRelativeTo(null);

        background = new ImageIcon(getClass().getResource("resources/background.jpg")).getImage();

        JLabel titleLabel = new JLabel("Safari Tycoon", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 48));
        titleLabel.setForeground(new Color(0, 0, 0)); // Gold

        JButton newGameButton = createStyledButton("New Game", new Color(76, 175, 80));
        JButton difficultyButton = createStyledButton("Difficulty: " + selectedDifficulty, new Color(33, 150, 243));
        JButton closeButton = createStyledButton("Close", new Color(244, 67, 54));

        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.getContentPane().add(new GameEngine(selectedDifficulty));
                mainFrame.revalidate();
                mainFrame.repaint();
            }
        });

        difficultyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (selectedDifficulty) {
                    case "Easy":
                        selectedDifficulty = "Medium";
                        break;
                    case "Medium":
                        selectedDifficulty = "Hard";
                        break;
                    case "Hard":
                        selectedDifficulty = "Easy";
                        break;
                }
                difficultyButton.setText("Difficulty: " + selectedDifficulty);
            }
        });

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Close the application
            }
        });

        // Layout setup using GridBagLayout
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 0, 15, 0);
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // New Game button
        gbc.gridy = 1;
        add(newGameButton, gbc);

        // Difficulty button
        gbc.gridy = 2;
        add(difficultyButton, gbc);

        // Close button
        gbc.gridy = 3;
        add(closeButton, gbc);

        // Make the panel visible
        setVisible(true);

        // Adding panel to the frame
        mainFrame.add(this);
        mainFrame.setVisible(true);
    }



    /**
     * A panelon található háttér és cím megjelenítéséért felelős metódus.
     * A háttérkép és a "Safari Tycoon" cím kirajzolására szolgál.
     *
     * @param g A grafikai objektum, amely a rajzoláshoz szükséges.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(background, 0, 0, getWidth(), getHeight(), null);
        // Cím rajzolása fehér szöveggel és fekete kontúrral
        Graphics2D g2d = (Graphics2D) g;
        g2d.setFont(new Font("Arial", Font.BOLD, 48));
        String title = "Safari Tycoon";

        int x = getWidth() / 2 - g2d.getFontMetrics().stringWidth(title) / 2;
        int y = 100;

        // Fekete körvonal (többször rajzoljuk eltolt pozíciókban)
        g2d.setColor(Color.BLACK);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx != 0 || dy != 0) {
                    g2d.drawString(title, x + dx, y + dy);
                }
            }
        }

        // Fehér szöveg
        g2d.setColor(Color.WHITE);
        g2d.drawString(title, x, y);
    }



    /**
     * Létrehoz egy gombot, amely stílusos megjelenéssel rendelkezik.
     * A gomb szövege, háttérszíne és egyéb tulajdonságai beállíthatók.
     *
     * @param text  A gomb szövege.
     * @param color A gomb háttérszíne.
     * @return A stílusos gomb.
     */
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 20));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 50)); // Adjust button size

        // Adding hover effect to the button
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }
}