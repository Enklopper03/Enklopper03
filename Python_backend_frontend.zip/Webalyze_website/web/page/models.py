from django.db import models

class DomainDecision(models.Model):
    domain = models.CharField(max_length=255, primary_key=True)
    decision = models.BooleanField()
    number = models.IntegerField(null=True, blank=True)
    generated_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.domain} - {'Igen' if self.decision else 'Nem'}"
