@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Üdvözöljük, {{ $user->name }}!</h1>

        <div class="row">
            <div class="col-md-4">
                <h3>Kifutók száma: {{ $enclosureCount }}</h3>
            </div>
            <div class="col-md-4">
                <h3>Állatok száma: {{ $animalCount }}</h3>
            </div>
        </div>

        <h3>Teendők:</h3>
        @if(count($feedingTimes) > 0)
            <ul>
                @foreach($feedingTimes as $feedingTime)
                    <li>
                        <strong>{{ $feedingTime['enclosure'] }}</strong> kifutóban
                        - Etetési idő: {{ $feedingTime['feeding_at']->format('H:i') }}
                    </li>
                @endforeach
            </ul>
        @else
            <p>Jelenleg nincs jövőbeli etetési időpont.</p>
        @endif

        {{-- <!-- Debug: Kiírja a feedingTimes változót -->
        <h3>Debug FeedingTimes:</h3>
        <pre>{{ print_r($feedingTimes, true) }}</pre> --}}

    </div>
@endsection
