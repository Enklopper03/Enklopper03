package src.moveables;

import javax.swing.*;



/**
 * A Leopard osztály a leopárdot reprezentálja a térképen.
 * A leopárd egy ragadozó állat, amely egy adott helyet foglal el a térképen.
 * A leopárd képe a "leopard.png" fájlból töltődik be.
 */
public class Leopard extends Carnivore {
    private static int idGen = 0;
    public static final int price = 320;
    public static final int sellPrice = 280;


    /**
     * Konstruktor, amely inicializálja a leopárd pozícióját, méretét és képét.
     *
     * @param x      A leopárd vízszintes koordinátája.
     * @param y      A leopárd függőleges koordinátája.
     * @param width  A leopárd szélessége.
     * @param height A leopárd magassága.
     */
    public Leopard(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/leopard.png").getImage(), "Leopard #" + (++idGen));
    }
}
