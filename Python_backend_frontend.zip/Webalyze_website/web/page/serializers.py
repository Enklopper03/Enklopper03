from rest_framework import serializers
from .models import DomainDecision
import re

class DomainDecisionSerializer(serializers.ModelSerializer):
    domain = serializers.CharField()

    class Meta:
        model = DomainDecision
        fields = '__all__'
        read_only_fields = ['decision', 'number', 'generated_at']

    def validate_domain(self, value):
        pattern = r'^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, value):
            raise serializers.ValidationError("Hibás domain formátum.")
        if len(value) > 255:
            raise serializers.ValidationError("A domain túl hosszú (max 255 karakter).")
        if len(value) == 0:
            raise serializers.ValidationError("Töltse ki a domain mezőt.")
        return value


class DomainDecisionUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DomainDecision
        fields = ['decision', 'number', 'generated_at']
        read_only_fields = ['domain']

    