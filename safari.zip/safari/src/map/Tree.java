package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Tree osztály a fát reprezentálja a térképen.
 * A fa egy olyan akadály, amely egy adott helyet foglal el a térképen.
 * A fa képe a "tree.png" fájlból töltődik be.
 */
public class Tree extends  Plant {
    public static final int price = 50;
    private int health = 50;

    /**
     * Konstruktor, amely inicializálja a fa pozícióját, méretét és képét.
     *
     * @param x      A fa vízszintes koordinátája.
     * @param y      A fa függőleges koordinátája.
     * @param width  A fa szélessége.
     * @param height A fa magassága.
     */
    public Tree(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/tree.png").getImage());
    }

    public int getHealth() {
        return health;
    }

    public void decreaseHealth(int amount) {
        health -= amount;
    }

    public void setHealth(int health) {
        this.health = health;
    }
    public boolean isDead() {
        return health <= 0;
    }

   
}