[X] - Adatbázis és modellek (3 pont)
[X] - Seeder (3 pont)
[X] - Főoldal (4 pont)
[X] - Kifutók listázása (3 pont)
[X] - Kifutó létrehozása (3 pont)
[X] - Kifutó szerkesztése (3 pont)
[X] - Kifutó törlése (3 pont)
[X] - Kifutó megjelenítése (4 pont)
[X] - Állat létrehozása (4 pont)
[X] - Állat szerkesztése (5 pont)
[X] - Állat archiválása (5 pont)
[X] - Archivált állatok listája (6 pont)
[ ] - Védésre szerezhető pontszám (4 pont)


A seederben generált:

admin:      email: admin@admin.com      password: admin
avg user:   email: seederben            password: password
