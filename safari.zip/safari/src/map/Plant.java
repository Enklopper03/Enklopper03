package src.map;

import java.awt.*;


/**
 * Az absztrakt Plant osztály azokat az objektumokat reprezentálja, amelyek növények a térképen, például fák, bokrok vagy fű.
 * Minden növény rendelkezik pozícióval, mérettel, képpel és hitbox-szal.
 */
public abstract class Plant {
    private  int x;
    private  int y;
    private  int width;
    private  int height;
    private Rectangle hitbox;

    private Image image;
    protected Image sprite;
    protected Point position;


    /**
     * Konstruktor, amely inicializálja a növény pozícióját, méretét, képét és hitbox-át.
     *
     * @param x      A növény vízszintes koordinátája.
     * @param y      A növény függőleges koordinátája.
     * @param width  A növény szélessége.
     * @param height A növény magassága.
     * @param image  A növényhez tartozó kép.
     */
    public Plant(int x, int y, int width, int height, Image image) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.hitbox = createHitbox();
        this.position = new Point(x, y);
    }


    /**
     * Kirajzolja a növényt a megadott Graphics2D objektummal.
     *
     * @param g2d A grafikai objektum, amelyre a növény képe lesz rajzolva.
     */
    public void draw(Graphics2D g2d) {
        g2d.drawImage(image, (int) x, (int) y, width, height, null);
    }





    public Rectangle createHitbox() {
        return new Rectangle(x, y, width, height);
    }

    public void updateHitbox() {
        this.hitbox = createHitbox();
    }
    public Rectangle getHitbox() {
        return hitbox;
    }

    public Point getPosition() {
        return position;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
