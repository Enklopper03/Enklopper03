<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Archivált állatok</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($animals->isEmpty()): ?>
        <p>Nincsenek archivált állatok.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Archiválás ideje</th>
                    <th>Visszaállítás</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($animal->name); ?></td>
                        <td><?php echo e($animal->species); ?></td>
                        <td><?php echo e($animal->deleted_at->format('Y-m-d H:i')); ?></td>
                        <td>
                            <form action="<?php echo e(route('animals.restore', $animal->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <select name="enclosure_id" class="form-control mb-2" required>
                                    <?php $__currentLoopData = $enclosures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enclosure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($enclosure->id); ?>"><?php echo e($enclosure->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Visszaállítás</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->admin): ?>
            <a href="<?php echo e(route('enclosure')); ?>" class="btn btn-secondary">Vissza a kifutókhoz</a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ELTE\Szerveroldaliweb\beadando\bead\resources\views/animals/archived.blade.php ENDPATH**/ ?>