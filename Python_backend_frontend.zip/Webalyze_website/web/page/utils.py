# utils.py
import random
from datetime import datetime, timedelta

def generate_domain_decision(domain):
    decision = random.choice([True, False])

    if not decision:
        return {
            "domain": domain,
            "decision": False,
            "number": None,
            "generated_at": None
        }

    number = random.randint(1, 3)
    delta_days = random.randint(0, 90)
    generated_at = datetime.now() - timedelta(days=delta_days)

    return {
        "domain": domain,
        "decision": True,
        "number": number,
        "generated_at": generated_at
    }
