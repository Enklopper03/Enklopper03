<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($enclosures->count() > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Név</th>
                        <th></th>
                        <th>Limit</th>
                        <th></th>
                        <th>Állatok száma</th>
                        <th></th>
                        <th>Akciók</th>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->admin): ?>
                            <th><a href="<?php echo e(route('enclosures.create')); ?>" class="btn btn-warning">Létrehozás</a></th>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $enclosures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enclosure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($enclosure->name); ?></td>
                            <td></td>
                            <td><?php echo e($enclosure->limit); ?></td>
                            <td></td>
                            <td><?php echo e($enclosure->animals_count); ?></td>
                            <td></td>
                            <td>
                                <a href="<?php echo e(route('enclosures.show',  $enclosure->id)); ?>" class="btn btn-warning">Megjelenítés</a></th>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->admin): ?>
                                        <a href="<?php echo e(route('enclosures.edit', $enclosure->id)); ?>" class="btn btn-warning">Szerkesztés</a>

                                        <form action="<?php echo e(route('enclosures.destroy', $enclosure->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Biztosan törölni akarod ezt a kifutót?');">Törlés</button>
                                        </form>
                                        <form action="<?php echo e(route('enclosures.clear', $enclosure->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Ürítés</button>
                                        </form>



                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($enclosures->links()); ?>

        <?php else: ?>
            <p>Nincsenek rendelt kifutók.</p>
        <?php endif; ?>

        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ELTE\Szerveroldaliweb\beadando\bead\resources\views/enclosure.blade.php ENDPATH**/ ?>