<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Üdvözöljük, <?php echo e($user->name); ?>!</h1>

        <div class="row">
            <div class="col-md-4">
                <h3>Kifutók száma: <?php echo e($enclosureCount); ?></h3>
            </div>
            <div class="col-md-4">
                <h3>Állatok száma: <?php echo e($animalCount); ?></h3>
            </div>
        </div>

        <h3>Teendők:</h3>
        <?php if(count($feedingTimes) > 0): ?>
            <ul>
                <?php $__currentLoopData = $feedingTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedingTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <strong><?php echo e($feedingTime['enclosure']); ?></strong> kifutóban
                        - Etetési idő: <?php echo e($feedingTime['feeding_at']->format('H:i')); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>Jelenleg nincs jövőbeli etetési időpont.</p>
        <?php endif; ?>

        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ELTE\Szerveroldaliweb\beadando\bead\resources\views/dashboard.blade.php ENDPATH**/ ?>