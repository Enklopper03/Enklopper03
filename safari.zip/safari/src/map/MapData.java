package src.map;

import src.main.GameEngine;
import src.moveables.*;
import src.utils.Direction;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.List;


/**
 * A MapData osztály felelős a térkép adatok betöltéséért és azok grafikai megjelenítéséért.
 * A térképet egy szöveges fájl alapján tölti be, ahol különböző elemeket (pl. fák, bokrok, állatok) helyez el a térképen.
 */
public class MapData {

    // A térképen található objektumok listái
    public List<Road> road;
    public Point entrance;
    public Point exit;
    private List<Tree> discoveredTrees;
    public List<Grass> grassyAreas;
    public List<Bush> bushes;
    public List<Tree> trees;
    public List<Herbivore> herbivores;
    public List<Lake> lakes;
    public List<Carnivore> carnivores;
    public List<Guard> guards;
    public List<Hunter> hunters;
    public List<River> rivers;
    public List<Hill> hills;



    /**
     * Konstruktor, amely betölti a térképet a megadott fájlból.
     * A fájl egy szöveges formátumban tartalmazza a térkép objektumait.
     *
     * @param levelPath A térképet tartalmazó fájl elérési útja.
     * @throws IOException Ha hiba történik a fájl beolvasása közben.
     */
    public MapData(String levelPath) throws IOException {
        this.loadLevel(levelPath);
    }

    //B - bush
    //T - tree
    //G - grass
    //I - giraffe
    //Z - zebra
    //L - lion
    //P - leopard
    //W - water
    //R - road
    //E - entrance
    //X - exit
    //O - hunter
    //G - grass
    //Q - river


    /**
     * A térkép adatainak betöltése a fájlból.
     * A fájl minden egyes karaktere egy-egy objektumot reprezentál, amelyet a megfelelő lista tartalmaz.
     *
     * @param levelPath A térkép fájl elérési útja.
     * @throws IOException Ha hiba történik a fájl beolvasása közben.
     * @throws FileNotFoundException Ha nem található a fájl.
     */
    public void loadLevel(String levelPath) throws IOException, FileNotFoundException {
        BufferedReader reader = new BufferedReader(new FileReader(levelPath));
        this.grassyAreas = new ArrayList<>();
        this.discoveredTrees = new ArrayList<>();
        this.lakes = new ArrayList<>();
        this.trees = new ArrayList<>();
        this.bushes = new ArrayList<>();
        this.carnivores = new ArrayList<>();
        this.herbivores = new ArrayList<>();
        this.road = new ArrayList<>();
        this.rivers = new ArrayList<>();
        this.guards = new ArrayList<>();
        this.hunters = new ArrayList<>();
        this.hills = new ArrayList<>();

        String line;
        int cellSize = 50;
        int y = 0;

        while ((line = reader.readLine()) != null) {
            char[] blocks = line.toCharArray();
            int x = 0;

            for (char blockType : blocks) {
                int posX = x * cellSize;
                int posY = y * cellSize;

                switch (blockType) {
                    case 'B':
                        this.bushes.add(new Bush(posX, posY, cellSize, cellSize));
                        break;
                    case 'T':
                        this.trees.add(new Tree(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'G':
                        this.grassyAreas.add(new Grass(posX, posY, 3 * cellSize, 2 * cellSize));
                        break;
                    case 'I':
                        this.herbivores.add(new Giraffe(posX, posY, 2 * cellSize, 2 * cellSize));
                        break;
                    case 'Z':
                        this.herbivores.add(new Zebra(posX, posY, 2 * cellSize, 2 * cellSize));
                        break;
                    case 'L':
                        this.carnivores.add(new Lion(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'P':
                        this.carnivores.add(new Leopard(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'W':
                        this.lakes.add(new Lake(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'R':
                        this.road.add(new Road(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'E':
                        this.road.add(new Road(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        entrance = new Point(posX, posY);
                        break;
                    case 'X':
                        this.road.add(new Road(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        exit = new Point(posX, posY);
                        break;
                    case 'O':
                        this.hunters.add(new Hunter(posX, posY, Direction.RIGHT, Direction.DOWN, 1, cellSize, cellSize));
                        break;
                    case 'Q':
                        this.rivers.add(new River(posX, posY, (int) (1.5 * cellSize), (int) (1.5 * cellSize)));
                        break;
                    case 'D':
                        this.hills.add(new Hill(posX, posY, (int) (3 * cellSize), (int) (3 * cellSize)));
                        break;
                }
                x++;
            }
            y++;
        }
        reader.close();
    }




    /**
     * A térképen található összes objektum kirajzolása.
     * Az objektumok megfelelő helyükön jelennek meg a képernyőn.
     *
     * @param g A grafikai objektum, amelyre a térképet rajzolni kell.
     */
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        for (Bush Bush : this.bushes) {
            Bush.draw(g2d);
        }
        for (Tree Tree : this.trees) {
            Tree.draw(g2d);
        }
        for (Grass Grass : this.grassyAreas) {
            Grass.draw(g2d);
        }
        for (Herbivore Herbivore : this.herbivores) {
            Herbivore.draw(g2d);
        }
        for (Carnivore Carnivore : this.carnivores) {
            Carnivore.draw(g2d);
        }
        for (Lake Lake : this.lakes){
            Lake.draw(g2d);
        }
        for (Road Road : this.road){
            Road.draw(g2d);
        }
        for (Jeep Jeep : GameEngine.jeeps){
            Jeep.draw(g2d);
        }
        for (Guard Guard : this.guards){
            Guard.draw(g2d);
        }
        for (Hunter Hunter : this.hunters){
            if(Hunter.isInvisible()){
                continue;
            }
            Hunter.draw(g2d);
        }
        for (River River : this.rivers){
            River.draw(g2d);
        }
        for (Hill Hill : this.hills){
            Hill.draw(g2d);
        }
    }

}