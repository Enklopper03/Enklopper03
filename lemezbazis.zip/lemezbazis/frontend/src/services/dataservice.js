import Axios from 'axios';

const instance = Axios.create({
    baseURL : 'http://localhost:3000/api',
    headers:{
        'Content-type': 'application/json'
    }
});

// Minden kérés előtt frissítsd a tokent!
instance.interceptors.request.use(config => {
    const token = sessionStorage.getItem("token");
    if (token) {
        config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config;
});

export default instance;