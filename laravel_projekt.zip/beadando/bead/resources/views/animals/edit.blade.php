@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Állat szerkesztése</h2>

    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <form method="POST" action="{{ route('animals.update', $animal) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label for="name" class="form-label">Név</label>
            <input type="text" name="name" id="name" class="form-control" value="{{ old('name', $animal->name) }}" required>
        </div>

        <div class="mb-3">
            <label for="species" class="form-label">Faj</label>
            <input type="text" name="species" id="species" class="form-control" value="{{ old('species', $animal->species) }}" required>
        </div>

        <div class="mb-3">
            <label for="born_at" class="form-label">Születési idő</label>
            <input type="date" name="born_at" id="born_at" class="form-control" value="{{ old('born_at', $animal->born_at) }}">

        </div>

        <div class="mb-3">
            <label for="is_predator" class="form-label">Ragadozó?</label>
            <select name="is_predator" id="is_predator" class="form-control" required>
                <option value="0" {{ old('is_predator', $animal->is_predator) == 0 ? 'selected' : '' }}>Nem</option>
                <option value="1" {{ old('is_predator', $animal->is_predator) == 1 ? 'selected' : '' }}>Igen</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="enclosure_id" class="form-label">Kifutó</label>
            <select name="enclosure_id" id="enclosure_id" class="form-control" required>
                @foreach($enclosures as $enclosure)
                    <option value="{{ $enclosure->id }}" {{ old('enclosure_id', $animal->enclosure_id) == $enclosure->id ? 'selected' : '' }}>
                        {{ $enclosure->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Kép feltöltése</label>
            <input type="file" name="image" id="image" class="form-control">
            @if ($animal->image)
                <div class="mt-2">
                    <img src="{{ Storage::url($animal->image) }}" alt="Current Image" width="150">
                    <p>Jelenlegi kép</p>
                </div>
            @endif
        </div>

        <button type="submit" class="btn btn-primary">Módosítás</button>
    </form>
</div>
@endsection
