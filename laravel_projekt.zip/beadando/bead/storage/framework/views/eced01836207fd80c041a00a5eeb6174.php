<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e($enclosure->name); ?></h2>

    <p><strong>Állat limit:</strong> <?php echo e($enclosure->limit); ?></p>
    <p><strong>Jelenlegi állatok száma:</strong> <?php echo e($enclosure->animals->count()); ?></p>

    <?php if($hasPredators): ?>
        <div class="alert alert-danger">
            ⚠️ FIGYELEM: Ragadozó(k) található(k) a kifutóban!
        </div>
    <?php endif; ?>

    <h3>Állatok a kifutóban:</h3>
    <?php if($enclosure->animals->isEmpty()): ?>
        <p>Nincsenek állatok a kifutóban.</p>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Kép</th>
                <th>Név</th>
                <th>Faj</th>
                <th>Születési idő</th>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->admin || $enclosure->user_id == auth()->id()): ?>
                        <th>Akciók</th>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->admin || $enclosure->user_id == auth()->id()): ?>
                <div class="mb-3">
                    <a href="<?php echo e(route('animals.create')); ?>" class="btn btn-success">Új állat létrehozása</a>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->admin): ?>
        <a href="<?php echo e(route('animals.archived')); ?>" class="btn btn-secondary">Archivált állatok</a>
    <?php endif; ?>
<?php endif; ?>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $enclosure->animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($animal->image): ?>
                            <img src="<?php echo e(asset('storage/' . $animal->image)); ?>" alt="Állat képe" width="80">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="Placeholder" width="80">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($animal->name); ?></td>
                    <td><?php echo e($animal->species); ?></td>
                    <td>
                        <?php if($animal->born_at): ?>
                            <?php echo e($animal->born_at); ?>

                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->admin || $animal->user_id == auth()->id()): ?>
                                <a href="<?php echo e(route('animals.edit', $animal->id)); ?>" class="btn btn-warning btn-sm">Szerkesztés</a>
                                <?php if(!$animal->deleted_at): ?>
                                    <form action="<?php echo e(route('animals.archive', $animal)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Archiválás</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">Archiválva</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
    <a href="<?php echo e(route('enclosure')); ?>" class="btn btn-secondary">Vissza a kifutókhoz</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ELTE\Szerveroldaliweb\beadando\bead\resources\views/enclosures/show.blade.php ENDPATH**/ ?>