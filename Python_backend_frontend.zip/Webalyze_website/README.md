# The project
This webapplication was designed for a job application. You can give a domain name and the server responds either with yes or no. If the decision is yes including the "yes", there will be other fields with attributes that are also saved in the database (randomly generared). Else there will be no saving at all. If you try to give a domain that already exist in the database it wont generate another attributes jsut gives back the saved version.


# Technology
The project was created with DJANGO python backend + POSTGRESQL + React.js frontend

# Prerequirements:
Python, Docker, postgre database

# Requriements
For the requriments I did a txt where you can see the required installations for the project to be able to run it.
# if you use docker composer it will download them automatically

# Database
We need a postgre database to be running I advise you to have the pgAdmin4 app for easier access
# if you use docker composer it will start the datavase automatically



# API DESIGN
This project provides a simple REST API for checking and storing domain-related decisions.

1. POST /check/
Checks whether a domain has already been evaluated. If not, it generates a random decision and number, and stores the result.

Request Body (application/json):
{
  "domain": "example.com"
}
Response (200 OK):
{
  "domain": "example.com",
  "decision": true,
  "number": 42,
  "generated_at": "2025-07-31T08:15:00Z"
}
Notes:
If the domain is already in the database, the existing result is returned.
If not, a new random decision is generated and stored.
number and generated_at are only included if the decision is true.
If the domain field is missing or invalid, a 400 Bad Request response is returned.

2. GET /
A simple HTML form view where users can submit a domain and receive the result via the backend logic.



3. GET api/list : It lists the domain datas from the database

HTTP 200 OK
Allow: GET, HEAD, OPTIONS
Content-Type: application/json
Vary: Accept

[
    {
        "domain": "asdasd.hu",
        "decision": true,
        "number": 2,
        "generated_at": "2025-05-04T07:20:40.960001Z"
    },
    {
        "domain": "facebook.com",
        "decision": true,
        "number": 3,
        "generated_at": "2025-05-24T07:20:49.817935Z"
    },
    {
        "domain": "aa.hu",
        "decision": true,
        "number": 3,
        "generated_at": "2025-06-10T08:12:43.426290Z"
    }
]


4. GET http://localhost:8000/api/check/facebook.com/
HTTP 200 OK
Allow: GET, HEAD, OPTIONS
Content-Type: application/json
Vary: Accept

{
    "domain": "facebook.com",
    "decision": true,
    "number": 3,
    "generated_at": "2025-05-24T07:20:49.817935Z"
}



5. DELETE http://localhost:8000/api/delete/facebook.com/

HTTP 200 OK

6. PUT http://localhost:8000/api/update/aa.hu/
Request Body (application/json):
{
  "number": 2
}


HTTP 200 OK
Allow: PUT, OPTIONS
Content-Type: application/json
Vary: Accept

{
    "decision": true,
    "number": 2,
    "generated_at": "2025-06-10T08:12:43.426290Z"
}




# .env build   both in the root and the web backend part:
DB_NAME=db_name
DB_USER=db_user
DB_PASSWORD=pswd
DB_HOST=localhost / db   depending on the way of running the code (docker needs : db, 
                                                                   manually from terminal with manage.py runserver needs : localhost)
DB_PORT=5432
SECRET_KEY=your-secret-key-here



# Test cases(located in page/tests.py):
1. Checks if the given domain name is in the wrong format and handles with status code : 400
2. Checks if the given domain name is in the right format and handles with status code : 200
3. Test case for the random number generator logic with mock numbers when the decision is true
4. Test case for the random number generator logic with mock numbers when the decision is false
5. Test case for the persistance logic when the decision is true
6. run the testcases (you need to go inside the web folder): docker-compose run web python manage.py test

# Commands:
1. using docker:
                    1.docker-compose up --build -d
                    2.docker-compose exec web python manage.py migrate
                    3.docker-compose exec web python manage.py createsuperuser
                    4.docker-compose up --build 
    
2. using localhost:
    1.server:    python .\manage.py runserver
    2.frontend:  npm install + npm install react-router-dom + npm run dev
            
