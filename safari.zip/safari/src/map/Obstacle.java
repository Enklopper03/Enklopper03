package src.map;

import java.awt.*;



/**
 * Az Obstacle (akadály) osztály egy absztrakt osztály, amely az akadályok (pl. növények, fák, építmények)
 * közös tulajdonságait és viselkedését reprezentálja. Az akadályok egy adott helyen helyezkednek el
 * a térképen, és rendelkeznek képpel, amely megjeleníti őket. Ezen kívül minden akadály rendelkezik
 * egy hitbox-szal, amely segít az ütközések kezelésében.
 */
public abstract class Obstacle {
    private  int x;
    private  int y;
    private  int width;
    private  int height;
    private Image image;
    protected Point position;
    private Rectangle hitbox;


    /**
     * Konstruktor, amely inicializálja az akadály pozícióját, méretét, képét és hitbox-át.
     *
     * @param x      Az akadály vízszintes pozíciója.
     * @param y      Az akadály függőleges pozíciója.
     * @param width  Az akadály szélessége.
     * @param height Az akadály magassága.
     * @param image  Az akadályhoz tartozó kép.
     */
    public Obstacle(int x, int y, int width, int height, Image image) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.hitbox = createHitbox();
        this.position = new Point(x, y);
    }

    /**
     * Az akadály kirajzolása a képernyőre a megadott Graphics2D objektummal.
     *
     * @param g2d A grafikai objektum, amelyre az akadály képe lesz rajzolva.
     */
    public void draw(Graphics2D g2d) {
        g2d.drawImage(image, (int) x, (int) y, width, height, null);
    }

    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    /**
     * Létrehozza és visszaadja az akadály hitbox-át (a terület, amelyen az akadály található).
     *
     * @return Az akadály hitbox-a, amely egy téglalap.
     */
    public Rectangle createHitbox() {
        return new Rectangle(x, y, width, height);
    }

    public void updateHitbox() {
        this.hitbox = createHitbox();
    }
    public Rectangle getHitbox() {
        return hitbox;
    }

    public Point getPosition() {
        return position;
    }


}
