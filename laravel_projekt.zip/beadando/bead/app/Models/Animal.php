<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Enclosure;

class Animal extends Model
{

    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'name',
        'species',
        'born_at',
        'is_predator',
        'enclosure_id',
        'image',
    ];

    protected $dates = ['born_at', 'deleted_at'];

    public function enclosure()
    {
        return $this->belongsTo(Enclosure::class);
    }

}
