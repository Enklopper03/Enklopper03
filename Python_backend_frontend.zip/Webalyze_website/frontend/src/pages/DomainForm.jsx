import React, { useState } from 'react';

const DomainForm = () => {
  const [domain, setDomain] = useState('');
  const [result, setResult] = useState('');

  const isWithinLast90Days = (dateString) => {
    if (!dateString) return false;
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffDays = diffMs / (1000 * 60 * 60 * 24);
    return diffDays <= 90 && diffDays >= 0;
  };

  const formatUSDate = (dateString) => {
    const date = new Date(dateString);
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const yyyy = date.getFullYear();
    const hh = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');

    return `${mm}/${dd}/${yyyy} ${hh}:${min}:${ss}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const pattern = /^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$/;
    if (!pattern.test(domain)) {
      alert("Hibás domain formátum.");
      return;
    }

    try {
      const response = await fetch("http://localhost:8000/api/check/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ domain })
      });

      const data = await response.json();

      if (data.decision === false) {
        setResult("Döntés: hamis");
      } else {
        let generatedAtText = 'N/A';
        if (isWithinLast90Days(data.generated_at)) {
          generatedAtText = formatUSDate(data.generated_at);
        }

        setResult(
          `Döntés: igaz\nDomain: ${data.domain}\nNumber: ${data.number}\nGenerálva: ${generatedAtText}`
        );
      }
    } catch (err) {
      console.error("Hiba a kérés során:", err);
      setResult("Hiba történt a szerverrel.");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Adj meg egy domaint:</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="pl. example.com"
          required
        />
        <button type="submit">Küldés</button>
      </form>
      <pre>{result}</pre>
    </div>
  );
};

export default DomainForm;
