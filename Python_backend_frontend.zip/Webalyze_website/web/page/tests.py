from django.test import TestCase
from .models import DomainDecision
from rest_framework.test import APIClient
from unittest.mock import patch
from datetime import timedelta
from django.utils import timezone


class DomainDecisionTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_domain_validation(self):
        res = self.client.post("/api/check/", {"domain": "notadomain"})
        self.assertEqual(res.status_code, 400)
        res2 = self.client.post("/api/check/", {"domain": "a"*300 + ".com"})
        self.assertEqual(res2.status_code, 400)
        res3 = self.client.post("/api/check/", {"domain": ""})
        self.assertEqual(res3.status_code, 400)

    def test_decision_generation(self):
        res = self.client.post("/api/check/", {"domain": "example.com"})
        self.assertEqual(res.status_code, 200)
        self.assertIn("decision", res.data)



class GenerateDomainDecisionTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    @patch("page.views.random.choice", return_value=True)
    @patch("page.views.random.randint", side_effect=[2, 10])
    def test_generate_decision_true(self, mock_randint, mock_choice):
        res = self.client.post("/api/check/", {"domain": "trueexample.com"})
        self.assertEqual(res.status_code, 200)
        self.assertTrue(res.data["decision"])
        self.assertEqual(res.data["number"], 2)
        self.assertIsNotNone(res.data["generated_at"])

    @patch("page.views.random.choice", return_value=False)
    def test_generate_decision_false(self, mock_choice):
        res = self.client.post("/api/check/", {"domain": "falseexample.com"})
        self.assertEqual(res.status_code, 200)
        self.assertFalse(res.data["decision"])
        self.assertIsNone(res.data["number"])
        self.assertIsNone(res.data["generated_at"])

    @patch("page.views.random.choice", return_value=True)
    @patch("page.views.random.randint", side_effect=[3, 20])
    def test_persistence_for_yes_decision(self, mock_randint, mock_choice):
        """
        Test that a domain decision is persisted in the database and returned on subsequent requests.

        This test simulates a scenario where the decision for a domain is generated and saved,
        and then checks that the same decision is returned on a subsequent request without generating a new one.
        """
        domain = "persistdomain.com"

        # first request – generate and save decision
        res1 = self.client.post("/api/check/", {"domain": domain})
        self.assertEqual(res1.status_code, 200)
        self.assertTrue(res1.data["decision"])
        self.assertEqual(res1.data["number"], 3)
        self.assertIsNotNone(res1.data["generated_at"])

        # Check that it has been saved to the database
        obj = DomainDecision.objects.get(domain=domain)
        self.assertTrue(obj.decision)
        self.assertEqual(obj.number, 3)

        # second request – should return the same
        res2 = self.client.post("/api/check/", {"domain": domain})
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res1.data, res2.data)

        # Ensure no new save occurred
        self.assertEqual(DomainDecision.objects.count(), 1)
