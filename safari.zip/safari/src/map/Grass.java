package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Grass osztály a füvet reprezentálja a térképen.
 * A fű egy olyan növény, amely egy adott helyet foglal el a térképen, és rendelkezik egy egészség értékkel,
 * amely csökkenhet, ha a fűt támadás éri. A fű képe a "grass.png" fájlból töltődik be.
 */
public class Grass extends Plant {
    public static final int price = 10;
    public int health = 20;


    /**
     * Konstruktor, amely inicializálja a fű pozícióját, méretét és képét.
     *
     * @param x      A fű vízszintes koordinátája.
     * @param y      A fű függőleges koordinátája.
     * @param width  A fű szélessége.
     * @param height A fű magassága.
     */
    public Grass(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/grass.png").getImage());
    }



    /**
     * A fű egészség értékének lekérdezése.
     *
     * @return A fű jelenlegi egészség értéke.
     */
    public int getHealth() {
        return health;
    }


    /**
     * A fű egészségének csökkentése egy megadott értékkel.
     *
     * @param amount Az egészség csökkentésének mértéke.
     */
    public void decreaseHealth(int amount) {
        health -= amount;
    }


    /**
     * Ellenőrzi, hogy a fű elpusztult-e (azaz az egészsége 0 vagy alatta van).
     *
     * @return true, ha a fű elpusztult; false, ha még életben van.
     */
    public boolean isDead() {
        return health <= 0;
    }

}
