<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\Enclosure;
use App\Models\Animal;
use Carbon\Carbon;
use Illuminate\Http\Request;

class EnclosureController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // Admin jogkör esetén az összes kifutó
        if ($user->admin) {
            // Az adminnak az összes kifutó megjelenítése
            $enclosuresQuery = Enclosure::with(['animals'])->withCount('animals')->orderBy('name');

        } else {
            // A nem-admin felhasználónak csak a saját kifutói
            $enclosuresQuery = $user->enclosures()->with(['animals'])->withCount('animals')->orderBy('name');
        }

        // 5 rekordos oldalazás
        $enclosures = $enclosuresQuery->paginate(5);


        return view('enclosure', [
            'enclosures' => $enclosures,
        ]);
    }
    public function create()
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    $users = \App\Models\User::where('admin', false)->get(); // csak nem-adminokat listázzuk
    return view('enclosures.create', compact('users'));
}


public function store(Request $request)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    // lehet mar nem szukseges
    if (preg_match('/^\d{2}:\d{2}$/', $request->feeding_at)) {
        $request->merge(['feeding_at' => $request->feeding_at . ':00']);
    }

    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'limit' => 'required|integer|min:1',
        'feeding_at' => 'required|date_format:H:i:s',
        'user_id' => 'required|exists:users,id',
    ]);

    // $feedingAt = Carbon::createFromFormat('H:i', $validated['feeding_at'])->format('H:i:s');

    $enclosure = Enclosure::create([
        'name' => $validated['name'],
        'limit' => $validated['limit'],
        'feeding_at' => $validated['feeding_at'],
    ]);

    $enclosure->users()->attach($validated['user_id']);

    return redirect()->route('enclosure')->with('success', 'Kifutó létrehozva és gondozóhoz rendelve.');
}
public function edit(Enclosure $enclosure)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    $users = \App\Models\User::where('admin', false)->get();
    $selectedUsers = $enclosure->users->pluck('id')->toArray();

    return view('enclosures.edit', compact('enclosure', 'users', 'selectedUsers'));
}

public function update(Request $request, Enclosure $enclosure)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'limit' => 'required|integer|min:1',
        'feeding_at' => 'required|date_format:H:i:s',
        'user_ids' => 'required|array',
        'user_ids.*' => 'exists:users,id',
    ]);


    $enclosure->update([
        'name' => $validated['name'],
        'limit' => $validated['limit'],
        'feeding_at' => $validated['feeding_at'],
    ]);

    $enclosure->users()->sync($validated['user_ids']);

    return redirect()->route('enclosure')->with('success', 'Kifutó sikeresen frissítve.');
}

public function destroy($id)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    $enclosure = Enclosure::withCount('animals')->findOrFail($id);

    if ($enclosure->animals_count > 0) {
        return redirect()->back()->with('error', 'A kifutó nem törölhető, mert még vannak benne állatok.');
    }

    $enclosure->delete();

    return redirect()->route('enclosure')->with('success', 'Kifutó sikeresen törölve.');
}
public function clear($id)
{
    if (!auth()->user()->admin) {
        abort(403);
    }

    $enclosure = Enclosure::findOrFail($id);

    // Összes állat törlése a kifutóból
    foreach ($enclosure->animals as $animal) {
        $animal->delete();
    }

    return redirect()->route('enclosure')->with('success', 'A kifutó kiürítve és az állatok törölve.');
}

public function show($id)
{
    $user = auth()->user();

    // Lekérjük a kifutót
    $enclosure = Enclosure::with(['animals' => function($query) {
        $query->orderBy('species')->orderBy('birthdate');
    }])->findOrFail($id);

    // Jogosultságellenőrzés: ha nem admin, akkor csak saját kifutókat nézhet
    if (!$user->admin && !$user->enclosures->contains($enclosure)) {
        abort(403);
    }

    // Ellenőrizzük, hogy van-e ragadozó
    $hasPredators = $enclosure->animals->contains(function ($animal) {
        return $animal->is_predator; // ezt majd Animal modelben is figyeljük
    });

    return view('enclosures.show', compact('enclosure', 'hasPredators'));
}



}
