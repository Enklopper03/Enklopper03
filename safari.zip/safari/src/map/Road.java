package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Road osztály az utat reprezentálja a térképen.
 * Az út egy olyan akadály, amely egy adott helyet foglal el a térképen.
 * Az út képe a "road.jpg" fájlból töltődik be.
 */
public class Road {
    public static final int price = 20;
    private  int x;
    private  int y;
    private  int width;
    private  int height;

    private Image image;


    /**
     * Konstruktor, amely inicializálja az út pozícióját, méretét és képét.
     *
     * @param x      Az út vízszintes koordinátája.
     * @param y      Az út függőleges koordinátája.
     * @param width  Az út szélessége.
     * @param height Az út magassága.
     */
    public Road(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = new ImageIcon("src/main/resources/road.jpg").getImage();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void draw(Graphics2D g2d) {

        g2d.drawImage(image, (int) x, (int) y, width, height, null);
    }
}
