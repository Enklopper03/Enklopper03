<template>
    <div>
        <div class="row g-3 mt-3">
        <div class="col-md-12">
          <label for="text" class="form-label">Kép feltöltése:</label>
          <input type="file" class="form-control">
        </div>
        <button class="btn btn-success">Feltöltés</button>
      </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>