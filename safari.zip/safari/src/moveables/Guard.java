package src.moveables;

import src.main.GameEngine;
import src.utils.Direction;

import java.awt.*;


/**
 * A Guard osztály a védelmezőt reprezentálja a térképen.
 * A védelmező egy mozgatható objektum, amely képes vadászni ragadozókra és vadászokra.
 */
public class Guard extends Moveable {

    public static final int price = 2500;
    private double speed = 1;

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    private  Carnivore huntedAnimal;
    private Hunter huntedHunter;
    private int salary;
    public Carnivore getHuntedAnimal() {
        return huntedAnimal;
    }
    public void setHuntedAnimal(Carnivore huntedAnimal) {
        this.huntedAnimal = huntedAnimal;
    }
    public Hunter getHuntedHunter() {return huntedHunter;}
    public void setHuntedHunter(Hunter huntedHunter) {this.huntedHunter = huntedHunter;}


    /**
     * Konstruktor, amely inicializálja a védelmező pozícióját, irányát, sebességét, méretét és képét.
     *
     * @param x           A védelmező vízszintes koordinátája.
     * @param y           A védelmező függőleges koordinátája.
     * @param directionX  A védelmező vízszintes iránya.
     * @param directionY  A védelmező függőleges iránya.
     * @param speed       A védelmező sebessége.
     * @param width      A védelmező szélessége.
     * @param height     A védelmező magassága.
     * @param image      A védelmező képe.
     * @param huntedAnimal Az a ragadozó, amelyet a védelmező vadászik.
     */
    public Guard(int x, int y, Direction directionX, Direction directionY, int speed, int width, int height, Image image, Carnivore huntedAnimal) {
        super(x, y, directionX, directionY, width, height, image);
        this.huntedAnimal = huntedAnimal;
    }



    /**
     * A védelmező lelő egy ragadozót (Carnivore) a térképről, ha az szerepel a listában.
     *
     * @param carnivore A lelőni kívánt ragadozó.
     */
    private void shootCarnivore(Carnivore carnivore) {
        if (GameEngine.mapData.carnivores.contains(carnivore) || GameEngine.carnivores.contains(carnivore)) {
            GameEngine.mapData.carnivores.remove(carnivore);
            GameEngine.carnivores.remove(carnivore);
            System.out.println("CARNIVORE HAS BEEN SHOT");
            GameEngine.money += 100;
            this.huntedAnimal = null;
        } else {
            System.out.println("CARNIVORE NOT FOUND IN THE LIST");
        }
    }


    /**
     * A védelmező lelő egy vadászt (Hunter) a térképről, ha az szerepel a listában.
     *
     * @param hunter A lelőni kívánt vadász.
     */
    private  void shootHunter(Hunter hunter){
        if (GameEngine.mapData.hunters.contains(hunter)) {
            GameEngine.mapData.hunters.remove(hunter);
            System.out.println("HUNTER HAS BEEN SHOT");
            this.huntedHunter = null;
        } else {
            System.out.println("HUNTER NOT FOUND IN THE LIST");
        }
    }


    /**
     * A védelmező megpróbálja lelőni a vadászt, ha az egy adott távolságon belül van.
     *
     * @param hunter A célzott vadász.
     * @param shootDistance A távolság, amelyen belül a védelmező lőni tud.
     */
    public void shootIfClose(Hunter hunter, double shootDistance) {
        double dx = getX() - hunter.getX();
        double dy = getY() - hunter.getY();
        double distance = Math.sqrt(dx * dx + dy * dy);

        if (distance <= shootDistance) {
            shootHunter(hunter);
        }
    }

    /**
     * A védelmező mozog a vadászott ragadozó (Carnivore) felé, amíg el nem éri azt.
     * Ha a távolság kisebb, mint 5, a védelmező lelövi a ragadozót.
     */

    @Override
    public void move() {
        if (huntedAnimal != null) {

            int guardX = getX();
            int guardY = getY();
            int targetX = huntedAnimal.getX();
            int targetY = huntedAnimal.getY();

            double dx = targetX - guardX;
            double dy = targetY - guardY;
            double distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 5) {
                shootCarnivore(this.huntedAnimal);
                return;
            }

            double moveX = (dx / distance) * speed;
            double moveY = (dy / distance) * speed;

            setX((int) (guardX + moveX));
            setY((int) (guardY + moveY));
        }
        else if(huntedHunter != null) {

            int guardX = getX();
            int guardY = getY();
            int targetX = huntedHunter.getX();
            int targetY = huntedHunter.getY();

            double dx = targetX - guardX;
            double dy = targetY - guardY;
            double distance = Math.sqrt(dx * dx + dy * dy);

            double moveX = (dx / distance) * speed;
            double moveY = (dy / distance) * speed;

            setX((int) (guardX + moveX));
            setY((int) (guardY + moveY));
        }
        else return;
    }
}
