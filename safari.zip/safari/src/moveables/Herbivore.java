package src.moveables;

import src.moveables.Animal;

import java.awt.*;
import java.util.Random;


/** A Herbivore osztály a növényevő állatokat reprezentálja a térképen.
 * A növényevő állatok egy adott helyet foglalnak el a térképen.
 * A növényevő állatok képe a "herbivore.png" fájlból töltődik be.
 */
public class Herbivore extends Animal {

    /**
     * Konstruktor a Herbviore (novenyevo) objektum létrehozásához.
     *
     * @param x az állat kezdő X koordinátája
     * @param y az állat kezdő Y koordinátája
     * @param width az állat szélessége
     * @param height az állat magassága
     * @param image az állat képe, amelyet megjelenítünk
     * @param name az állat neve
     */
    public Herbivore(int x, int y, int width, int height, Image image, String name) {
        super(x, y, width, height, image, name);
    }

    @Override
    public boolean isDead() {
        return getHealth() <= 0;
    }

//    @Override
//    public void draw(Graphics g) {
//        g.drawImage(sprite, position.x, position.y, null); // Rajzolás
//    }


}
