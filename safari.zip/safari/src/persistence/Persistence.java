package src.persistence;

public class Persistence {
}
