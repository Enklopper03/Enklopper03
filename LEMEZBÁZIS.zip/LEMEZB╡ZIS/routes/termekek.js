const express = require("express");
const {getTermekek, getTermek, addTermek, updateTermek, deleteTermek } = require("../controllers/termekek");

const Termek = require('../models/Termek')
const advancedResults = require('../middleware/advancedResults')

const router = express.Router( {mergeParams:true});//KÁPOSZTA

const { protect, authorize } = require('../middleware/auth')

router.route('/')
  .get(advancedResults(Termek, {
    path: 'lemezId'
  }), getTermekek)
  .post(addTermek)

router.route('/:id')
  .get(getTermek)
  .put(updateTermek)
  .delete(deleteTermek)

module.exports = router;



//szoftver_fejleszto_kurzusok_api