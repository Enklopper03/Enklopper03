@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Kifutó létrehozása</h2>

    <form method="POST" action="{{ route('enclosures.store') }}">
        @csrf

        <div class="mb-3">
            <label for="name" class="form-label">Név</label>
            <input type="text" name="name" id="name" class="form-control" value="{{ old('name') }}" required>
            @error('name')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="limit" class="form-label">Állat limit</label>
            <input type="number" name="limit" id="limit" class="form-control" min="1" value="{{ old('limit') }}" required>
            @error('limit')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="feeding_at" class="form-label">Etetés ideje (HH:MM)</label>
            <small class="text-muted">Pl: 08:00:00</small>
            <input type="text" name="feeding_at" id="feeding_at" class="form-control" placeholder="HH:MM:SS" value="{{ old('feeding_at') }}" required>
            @error('feeding_at')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="user_id" class="form-label">Gondozó kiválasztása</label>
            <select name="user_id" id="user_id" class="form-control" required>
                @foreach($users as $user)
                    <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->email }})
                    </option>
                @endforeach
            </select>
            @error('user_id')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Létrehozás</button>
    </form>
</div>
@endsection
