@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Archivált állatok</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if($animals->isEmpty())
        <p>Nincsenek archivált állatok.</p>
    @else
        <table class="table">
            <thead>
                <tr>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Archiválás ideje</th>
                    <th>Visszaállítás</th>
                </tr>
            </thead>
            <tbody>
                @foreach($animals as $animal)
                    <tr>
                        <td>{{ $animal->name }}</td>
                        <td>{{ $animal->species }}</td>
                        <td>{{ $animal->deleted_at->format('Y-m-d H:i') }}</td>
                        <td>
                            <form action="{{ route('animals.restore', $animal->id) }}" method="POST" class="d-inline">
                                @csrf
                                <select name="enclosure_id" class="form-control mb-2" required>
                                    @foreach($enclosures as $enclosure)
                                        <option value="{{ $enclosure->id }}">{{ $enclosure->name }}</option>
                                    @endforeach
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Visszaállítás</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
    @auth
        @if(auth()->user()->admin)
            <a href="{{ route('enclosure') }}" class="btn btn-secondary">Vissza a kifutókhoz</a>
        @endif
    @endauth
</div>
@endsection
