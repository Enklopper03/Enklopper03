package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Bush osztály a bokrokat reprezentálja a térképen.
 * A bokor egy olyan növény, amely egy bizonyos helyet foglal el a térképen, és rendelkezik egy egészség értékkel,
 * amely csökkenhet, ha a bokrot támadás éri. A bokor képe a "bush.png" fájlból töltődik be.
 */
public class Bush extends  Plant {
    public static final int price = 20;
    public int health = 30;


    /**
     * Konstruktor, amely inicializálja a bokor pozícióját, méretét és képét.
     *
     * @param x      A bokor vízszintes koordinátája.
     * @param y      A bokor függőleges koordinátája.
     * @param width  A bokor szélessége.
     * @param height A bokor magassága.
     */
    public Bush(int x, int y, int width, int height) {
        super(x, y, width, height, new ImageIcon("src/main/resources/bush.png").getImage());
    }

    /**
     * A bokor egészség értékének lekérdezése.
     *
     * @return A bokor jelenlegi egészség értéke.
     */
    public int getHealth() {
        return health;
    }


    /**
     * A bokor egészségének csökkentése egy megadott értékkel.
     *
     * @param amount Az egészség csökkentésének mértéke.
     */
    public void decreaseHealth(int amount) {
        health -= amount;
    }


    /**
     * Ellenőrzi, hogy a bokor elpusztult-e (azaz az egészsége 0 vagy alatta van).
     *
     * @return true, ha a bokor elpusztult; false, ha még életben van.
     */
    public boolean isDead() {
        return health <= 0;
    }

}