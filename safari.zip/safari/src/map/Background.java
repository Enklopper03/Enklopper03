package src.map;

import javax.swing.*;
import java.awt.*;
import java.util.Set;


public class Background {
    private Image grassTexture;
    private int tileSize = 40;

    public Background() {
        ImageIcon icon = new ImageIcon("src/main/resources/grass2.png");
        grassTexture = icon.getImage().getScaledInstance(tileSize, tileSize, Image.SCALE_SMOOTH);
    }

    public Image getGrassTexture() {
        return grassTexture; // Visszaadja a háttérkép Image objektumot
    }

    public void draw(Graphics g, int width, int height, Set<Point> occupiedTiles) {
        for (int x = 0; x < width; x += tileSize) {
            for (int y = 0; y < height; y += tileSize) {
                Point tile = new Point(x, y);
                if (!occupiedTiles.contains(tile)) {
                    g.drawImage(grassTexture, x, y, tileSize, tileSize, null);
                }
            }
        }
    }
}
