package src.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.main.GameEngine;
import static org.junit.jupiter.api.Assertions.*;

public class GameEngineTest {

    private GameEngine gameEngine;

    @BeforeEach
    void setUp() {


        gameEngine = new GameEngine("Easy");
        gameEngine.createToolbar();

    }

    @Test
    void testHerbivoreCount() {
        assertEquals(5, gameEngine.getHerbivoreCount(), "A level0 palyan 3 novenyevovel indul");
    }

    @Test
    void testCarnivoreCount() {
        assertEquals(6, gameEngine.getCarnivoreCount(), "A level0 palyan 4 ragadozoval indul");
    }

    @Test
    void testDayProgress() {
        int initialDay = gameEngine.dayCount;

        int ticksPerPhase = gameEngine.currentPhaseDuration / gameEngine.speed;
        int totalPhases = 2; // pl. Nappal, Éjjel

        for (int i = 0; i < ticksPerPhase * totalPhases; i++) {
            gameEngine.updateDayProgress();
        }

        assertEquals(initialDay + 1, gameEngine.dayCount, "Day count should increment after a full day cycle");
    }

    @Test
    void testHerbivoreDrinksWhenThirsty() {
        var herbivore = gameEngine.mapData.herbivores.get(0);
        herbivore.setThirstLevel(100); // legyen szomjas

        // Tegyük úgy, mintha a tóval ütközne
        var lake = gameEngine.mapData.lakes.get(0);
        herbivore.setPosition(lake.getPosition()); // ugyanarra a pontra

        gameEngine.setDiscoveredFoodAndDrinks();

        assertTrue(herbivore.getThirstLevel() < 100, "A herbivore ivott, tehát a szomjúságszint csökkent");
    }

    @Test
    void testDeadPlantsAreRemoved() {
        int initialTreeCount = gameEngine.mapData.trees.size();

        // Halottá tesszük az első fát
        var tree = gameEngine.mapData.trees.get(0);
        tree.setHealth(0); // feltételezve, hogy ettől meghal

        gameEngine.checkAndRemoveThings();

        int newTreeCount = gameEngine.mapData.trees.size();
        assertEquals(initialTreeCount - 1, newTreeCount, "A halott fa eltávolításra került");
    }

    @Test
    void testCarnivoreAttacksHerbivore() {
        var carnivore = gameEngine.mapData.carnivores.get(0);
        var herbivore = gameEngine.mapData.herbivores.get(0);

        carnivore.setHungerLevel(100); // legyen éhes

        // Támadási pozícióra állítjuk (összeérnek)
        carnivore.setPosition(herbivore.getPosition());

        gameEngine.setDiscoveredFoodAndDrinks();

        // Tegyük fel, hogy a támadás után a herbivore élete csökken
        assertTrue(herbivore.getHealth() < 100, "A carnivore megtámadta a herbivore-t");
    }

    @Test
    void testLoseAllAnimals() {
        gameEngine.mapData.herbivores.clear();
        gameEngine.mapData.carnivores.clear();

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.LOST_ALL_ANIMALS, status);
    }

    @Test
    void testLoseNoMoney() {
        gameEngine.money = 0;

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.LOST_NO_MONEY, status);
    }

    @Test
    void testWinEasyMode() {
        gameEngine.difficulty = "Easy";
        gameEngine.money = 100;
        gameEngine.streakCount = 10;

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.WON_EASY, status);
    }

    @Test
    void testWinMediumMode() {
        gameEngine.difficulty = "Medium";
        gameEngine.streakCount = 20;
        gameEngine.money = 200;

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.WON_MEDIUM, status);
    }

    @Test
    void testWinHardMode() {
        gameEngine.difficulty = "Hard";
        gameEngine.money = 500;
        gameEngine.streakCount = 30;

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.WON_HARD, status);
    }

    @Test
    void testOngoingGame() {
        gameEngine.difficulty = "Medium";
        gameEngine.streakCount = 5;
        gameEngine.money = 100;

        GameEngine.GameStatus status = gameEngine.evaluateGameStatus();
        assertEquals(GameEngine.GameStatus.ONGOING, status);
    }








}