package src.map;

import javax.swing.*;
import java.awt.*;


/**
 * A Lake osztály a tavat reprezentálja a térképen.
 * A tó egy olyan akadály, amely egy adott helyet foglal el a térképen.
 * A tó képe a "lake.png" fájlból töltődik be.
 */
public class Lake {
    public static final int price = 40;

    private  int x;
    private  int y;
    private  int width;
    private  int height;
    private Rectangle hitbox;
    public int health = 1000;
    protected Point position;
    private Image image;


    /**
     * Konstruktor, amely inicializálja a tó pozícióját, méretét és képét.
     *
     * @param x      A tó vízszintes koordinátája.
     * @param y      A tó függőleges koordinátája.
     * @param width  A tó szélessége.
     * @param height A tó magassága.
     */
    public Lake(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = new ImageIcon("src/main/resources/lake.png").getImage();
        this.position = new Point(x, y);
        this.hitbox = createHitbox();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    public Rectangle getHitbox() {
        return hitbox;
    }
    public Rectangle createHitbox() {
        return new Rectangle(x, y, width, height);
    }

    public Point getPosition() {
        return position;
    }

    public int getHealth() {
        return health;
    }

    public Point getCenter() {
        return new Point(x + width / 2, y + height / 2);
    }


    /**
     * A tó egészség értékének lekérdezése.
     *
     * @return A tó jelenlegi egészség értéke.
     */
    public void decreaseHealth(int amount) {
        health -= amount;
        if (health < 0) {
            health = 0;
        }
    }


    /**
     * Ellenőrzi, hogy a tó elpusztult-e (azaz az egészsége 0 vagy alatta van).
     *
     * @return true, ha a tó elpusztult; false, ha még életben van.
     */
    public boolean isDead() {
        return health <= 0;
    }

    public void draw(Graphics2D g2d) {
        g2d.drawImage(image, (int) x, (int) y, width, height, null);
    }
}
