package src.moveables;

import src.map.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.*;


/**
 * Az absztrakt Animal osztály az állatokat reprezentálja, amelyek a térképen mozognak, különböző viselkedési és életciklus jellemzőkkel,
 * mint például éhség, szomjúság, pihenés, szaporodás és mozgás.
 */
public abstract class Animal {

    private int age;
    private long lastBreedTime = 0; // időbélyeg az utolsó szaporodásról
    private int health = 40;
    private int hungerLevel = 65;
    private int thirstLevel = 65;
    private MapData mapdata;
    private Point destinationPoint;
    private Rectangle hitbox;
    protected int speed;
    protected Point position;
    private boolean hasLocator = false;
    private boolean showHitbox = false;

    private int x;
    private int y;
    private int width;
    private int height;
    private Image image;
    private String name;
    private boolean isResting = false;
    private long restStartTime = 0;
    private static final long REST_DURATION = 5000; // 5 másodperc pihenés

    public long lastAgeUpdateTime = System.currentTimeMillis();


    /**
     * Visszaadja az állat képét.
     *
     * @return Az állat képének ikonja.
     */
    public ImageIcon getImage() {
        Image newimg = image.getScaledInstance(30, 30,  java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(newimg);
    }

    public String getName() {
        return name;
    }


    /**
     * Ellenőrzi, hogy az állat rendelkezik-e helymeghatározóval.
     *
     * @return Igaz, ha van helymeghatározó, különben hamis.
     */
    public boolean hasLocator() {
        return hasLocator;
    }


    /**
     * Konstruktor, amely inicializálja az állat pozícióját, méretét, képét és nevét.
     *
     * @param x      Az állat vízszintes koordinátája.
     * @param y      Az állat függőleges koordinátája.
     * @param width  Az állat szélessége.
     * @param height Az állat magassága.
     * @param image  Az állathoz tartozó kép.
     * @param name   Az állat neve.
     */
    public Animal(int x, int y, int width, int height, Image image, String name) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.name = name;
        this.position = new Point(x, y);
        this.hitbox = createHitbox();
        this.speed = 2;
        this.mapdata = mapdata;
    }



    public int getSpeed() {
        return speed;
    }

    /**
     * Beállítja az állat sebességét.
     *
     * @param speed Az állat új sebessége.
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public void resetSpeed() {
        this.speed = 2;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public Point getPosition() { return position; }
    public void setDestination(Point p) { this.destinationPoint = p; }
    public Point getDestination() { return destinationPoint; }
    public void setShowHitbox(boolean showHitbox) { this.showHitbox = showHitbox; }

    public Rectangle createHitbox() {
        return new Rectangle(x, y, width, height);
    }

    public void updateHitbox() {
        this.hitbox = createHitbox();
    }

    public void setHungerLevel(int hungerLevel) {
        this.hungerLevel = hungerLevel;
    }

    public void setThirstLevel(int thirstLevel) {
        this.thirstLevel = thirstLevel;
    }


    public void setPosition(Point position) {
        this.position = position;
        this.x = position.x;
        this.y = position.y;
        updateHitbox();
    }
    public Rectangle getHitbox() {
        return hitbox;
    }

    public boolean isHungry() {
        return hungerLevel >= 50;
    }

    public boolean isFull() {
        return hungerLevel <= 20;
    }

    public boolean isThirsty() {
        return thirstLevel >= 50;
    }



    /**
     * Az állat mozgása a célpont felé a megadott sebességgel.
     *
     * @param target A célpont pozíciója.
     * @param speed  Az állat mozgási sebessége.
     */
    public void moveTowards(Point target, int speed) {
        if (isResting) {
            long now = System.currentTimeMillis();
            if (now - restStartTime >= REST_DURATION) {
                isResting = false;
                System.out.println("Állat befejezte a pihenést.");
            } else {
                return; // még mindig pihen
            }
        }

        double dx = target.x - x;
        double dy = target.y - y;
        double distance = Math.sqrt(dx * dx + dy * dy);

        if (distance > 1) {
            x += (dx / distance) * speed;
            y += (dy / distance) * speed;
            position.setLocation(x, y);
        }

        if (distance < 5) {
            destinationPoint = null;
        }
        updateHitbox();
    }


    /**
     * Az állat mozgásának irányítása a csordához való igazodással.
     *
     * @param herd A csorda állatai.
     */
    public void adjustTowardsHerd(List<? extends Animal> herd) {
        if (herd.size() <= 1) return;

        double centerX = 0, centerY = 0;
        for (Animal a : herd) {
            centerX += a.getX();
            centerY += a.getY();
        }
        centerX /= herd.size();
        centerY /= herd.size();

        double dx = centerX - x;
        double dy = centerY - y;
        double dist = Math.sqrt(dx * dx + dy * dy);

        if (dist > 100) {
            x += (dx / dist);
            y += (dy / dist);
        }

        double repelX = 0;
        double repelY = 0;
        for (Animal a : herd) {
            if (a == this) continue;
            double dx2 = x - a.getX();
            double dy2 = y - a.getY();
            double dist2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);

            if (dist2 > 0 && dist2 < 40) {
                repelX += dx2 / dist2;
                repelY += dy2 / dist2;
            }
        }

        x += repelX;
        y += repelY;
        position.setLocation(x, y);
        updateHitbox();
    }


    /**
     * Frissíti az állat célját a csoport dinamikájának és környezeti tényezőknek megfelelően.
     *
     * Ha az állat növényevő, akkor megpróbálja elkerülni a közelben lévő ragadozókat,
     * különben véletlenszerű helyre mozog. A vezető állat (a csoport első tagja) új célpontot
     * kap, és az alárendelt állatok követik, de egy kis szórással.
     *
     * @param herd a csoport tagjait tartalmazó lista
     * @param allAnimals az összes állatot tartalmazó lista
     * @param maxX a világ szélessége
     * @param maxY a világ magassága
     */
    public void maybeUpdateDestinations(List<Animal> herd, List<Animal> allAnimals, int maxX, int maxY) {
        if (herd.isEmpty()) return;

        Animal leader = herd.get(0);
        Random rand = new Random();

        List<Point> carnivorePositions = new ArrayList<>();
        if (this instanceof src.moveables.Herbivore) {
            for (Animal a : allAnimals) {
                if (a instanceof src.moveables.Carnivore) {
                    double distance = this.position.distance(a.getPosition());
                    if (distance < 200) {
                        carnivorePositions.add(a.getPosition());
                    }
                }
            }
        }

        if (this.getDestination() == null || this.position.distance(this.getDestination()) < 5 || this.position.x < 50 || this.position.y < 50) {
            int newX = rand.nextInt(maxX - 100) + 50;
            int newY = rand.nextInt(maxY - 100) + 50;
            this.setDestination(new Point(newX, newY));
        }

        if (!carnivorePositions.isEmpty()) {
            double avoidX = 0, avoidY = 0;
            for (Point p : carnivorePositions) {
                avoidX += p.x;
                avoidY += p.y;
            }
            avoidX /= carnivorePositions.size();
            avoidY /= carnivorePositions.size();

            double dirX = x - avoidX;
            double dirY = y - avoidY;
            double length = Math.sqrt(dirX * dirX + dirY * dirY);

            if (length > 0) {
                dirX = (dirX / length) * 100;
                dirY = (dirY / length) * 100;

                int targetX = (int) Math.max(20, Math.min(x + dirX + rand.nextInt(41) - 20, maxX - 20));
                int targetY = (int) Math.max(20, Math.min(y + dirY + rand.nextInt(41) - 20, maxY - 20));

                setDestination(new Point(targetX, targetY));
                return;
            }
        }

        if (this == leader) {
            int newX = rand.nextInt(maxX - 40) + 20;
            int newY = rand.nextInt(maxY - 40) + 20;
            setDestination(new Point(newX, newY));
        } else {
            Point leaderPos = leader.getPosition();
            int offsetX = rand.nextInt(41) - 20;
            int offsetY = rand.nextInt(41) - 20;

            int scatteredX = Math.max(20, Math.min(leaderPos.x + offsetX, maxX - 20));
            int scatteredY = Math.max(20, Math.min(leaderPos.y + offsetY, maxY - 20));

            setDestination(new Point(scatteredX, scatteredY));
            updateHitbox();
        }
    }


    /**
     * Kirajzolja az állatot a megadott Graphics objektumra.
     *
     * Az állat képe a pozícióján jelenik meg, és opcionálisan megjeleníti a hitbox-ot is,
     * ha a showHitbox változó igaz.
     *
     * @param g a Graphics objektum, amire az állatot kell rajzolni
     */
    public void draw(Graphics g) {
        g.drawImage(image, x, y, width, height, null);

        if (showHitbox) {
            updateHitbox();
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.RED);
            g2d.draw(hitbox);
        }
    }


    private long lastMovedTime = System.currentTimeMillis();
    private Point lastPosition = new Point(x, y);


    /**
     * Ellenőrzi, hogy az állat beragadt-e, és ha igen, új célpontot generál.
     *
     * Ha az állat nem mozdult el 3 másodperc alatt, új célpontot választ.
     *
     * @param maxX a világ szélessége
     * @param maxY a világ magassága
     */
    public void checkStuckAndRedirect(int maxX, int maxY) {
        long now = System.currentTimeMillis();
        if (position.distance(lastPosition) < 3 && now - lastMovedTime > 3000) {
            // Új cél generálása, ha beragadt
            Random rand = new Random();
            int newX = rand.nextInt(maxX - 100) + 50;
            int newY = rand.nextInt(maxY - 100) + 50;
            setDestination(new Point(newX, newY));
            System.out.println("Állat beragadt, új cél generálva!");
            lastMovedTime = now;
        }

        if (position.distance(lastPosition) >= 3) {
            lastMovedTime = now;
            lastPosition = new Point(position);  // frissítjük a korábbi pozíciót
        }
    }


    public int getAge() { return age; }
    public int getHealth() { return health; }
    public void decreaseHealth(int amount) { health -= amount; }
    public boolean isDead() { return health <= 0 || age > 10; }
    public int getHungerLevel() { return hungerLevel; }
    public int getThirstLevel() { return thirstLevel; }


    /**
     * Növényevő állatok étkezési logikáját kezeli.
     * Az állat eszik a fákról, bokrokról vagy fűről, ha azok elérhetőek.
     *
     * @param trees a fákat tartalmazó lista
     * @param bushes a bokrokat tartalmazó lista
     * @param grasses a füvet tartalmazó lista
     */
    public void eat(List<Tree> trees, List<Bush> bushes, List<Grass> grasses) {
        for (Tree tree : trees) {
            if (this.getHitbox().intersects(tree.getHitbox())) {
                this.hungerLevel = Math.max(0, hungerLevel - 50);
                int oldHealth = tree.getHealth();
                tree.decreaseHealth(50);
                System.out.println("Herbivore evett egy fánál! Health: " + oldHealth + " → " + tree.getHealth());
                return;
            }
        }

        for (Bush bush : bushes) {
            if (this.getHitbox().intersects(bush.getHitbox())) {
                bush.decreaseHealth(30);
                this.hungerLevel = Math.max(0, hungerLevel - 30);
                int oldHealth = bush.getHealth();
                System.out.println("Herbivore evett egy bokornál! Health: " + oldHealth + " → " + bush.getHealth());
                return;
            }
        }

        for (Grass grass : grasses) {
            if (this.getHitbox().intersects(grass.getHitbox())) {
                grass.decreaseHealth(20);
                this.hungerLevel = Math.max(0, hungerLevel - 20);
                System.out.println("Herbivore evett egy füves részen! Health: " + grass.getHealth());
                return;
            }
        }
    }


    /**
     * Ragadozó állatok étkezési logikáját kezeli.
     * A ragadozó megeheti a növényevő állatokat, ha azok a közelében vannak.
     *
     * @param herbivores a növényevő állatokat tartalmazó lista
     */
    public void huntherb(List<Herbivore> herbivores) {
        for (Herbivore herbivore : herbivores) {
            if (this.getHitbox().intersects(herbivore.getHitbox())) {
                this.hungerLevel = Math.max(0, hungerLevel - 50);
                int oldHealth = herbivore.getHealth();
                herbivore.decreaseHealth(100);
                System.out.println("Carnivore evett egy növényevőt! Health: " + oldHealth + " → " + herbivore.getHealth());
                return;
            }
        }
    }


    /**
     * Az állat szomjúságát csökkenti, ha a közelében van tó vagy folyó.
     *
     * @param lakes a tavakat tartalmazó lista
     * @param rivers a folyókat tartalmazó lista
     */
    public void drink(List<Lake> lakes , List<River> rivers) {
        for (Lake lake : lakes) {
            if (this.getHitbox().intersects(lake.getHitbox())) {
                lake.decreaseHealth(50);
                this.thirstLevel = Math.max(0, thirstLevel - 50);
                int oldHealth = lake.getHealth();
                System.out.println("Ivott a tónál! Lake health: " + oldHealth + " → " + lake.getHealth());
                return;
            }
        }
        for (River river : rivers) {
            if (this.getHitbox().intersects(river.getHitbox())) {
                river.decreaseHealth(50);
                this.thirstLevel = Math.max(0, thirstLevel - 50);
                int oldHealth = river.getHealth();
                System.out.println("Ivott a folyónál! River health: " + oldHealth + " → " + river.getHealth());
                return;
            }
        }
    }


    /**
     * Az állat pihenni kezd, ha elérte a telítettségi szintet.
     * Az állat csak akkor pihenhet, ha tele van és nem pihent még.
     */
    public void rest() {
        if (!isResting && isFull()) {
            isResting = true;
            restStartTime = System.currentTimeMillis();
            System.out.println("Állat pihenni kezdett!");
        }
    }


    /**
     * Két hasonló állat szaporodásának logikáját kezeli, ha azok megfelelő életkorúak és közel vannak egymáshoz.
     *
     * @param others az összes többi állatot tartalmazó lista
     * @return egy új állat, amely a két szülő állat hibridjeként jön létre, vagy null, ha nem történt szaporodás
     */
    public Animal breed(List<Animal> others) {
        if (age < 2) return null;


        long now = System.currentTimeMillis();
        if (now - lastBreedTime < 30_000) return null; // 30 másodperc korlátozás

        for (Animal other : others) {
            if (other == this) continue;
            if (other.getClass() == this.getClass() && other.age >= 2) {
                if (this.getHitbox().intersects(other.getHitbox())) {
                    this.lastBreedTime = now;
                    other.lastBreedTime = now;

                    int childX = (this.getX() + other.getX()) / 2;
                    int childY = (this.getY() + other.getY()) / 2;
                    int cellSize = 50;
                    // Visszatér egy új példánnyal
                    switch (this) {
                        case Giraffe giraffe -> {
                            return new Giraffe(childX, childY, (int) 1.5 * cellSize, (int) 1.5 * cellSize);
                        }
                        case Lion lion -> {
                            return new Lion(childX, childY, (int) 1.2 * cellSize, (int) 1.2 * cellSize);
                        }
                        case Zebra zebra -> {
                            return new Zebra(childX, childY, (int) 1.5 * cellSize, (int) 1.5 * cellSize);
                        }
                        case Leopard leopard -> {
                            return new Leopard(childX, childY, (int) 1.2 * cellSize, (int) 1.2 * cellSize);
                        }
                        default -> {
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Az állat életkorát és szükségleteit frissíti.
     * Az állat életkora 30 másodpercenként nő, és ennek megfelelően nő az éhség és szomjúság szintje is.
     * Ha az éhség vagy szomjúság túl magas, az állat egészsége csökken.
     */
    public void ageUp() {
        long now = System.currentTimeMillis();
        long elapsed = now - lastAgeUpdateTime;

        if (elapsed >= 30_000) {
            age += 1;
            hungerLevel += 20;
            thirstLevel += 20;

            if (hungerLevel >= 70 || thirstLevel >= 70) {
                health -= 20;
            }

            if (hungerLevel >= 100 || thirstLevel >= 100) {
                hungerLevel = 100;
                thirstLevel = 100;
            }

            System.out.println("Kor: " + age + ", Éhség: " + hungerLevel + ", Szomjúság: " + thirstLevel + ", HP: " + health);
            lastAgeUpdateTime = now;
        }
    }


    /**
     * Vásárol egy nyomkövetőt az állathoz, amellyel könnyebben nyomon követhetővé válik.
     */
    public void buyLocatorForAnimal() {
        hasLocator = true;
    }
}
